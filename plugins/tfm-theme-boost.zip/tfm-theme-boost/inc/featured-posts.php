<?php 

$html = '';

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! is_category() || false === apply_filters( 'tfm_theme_supports_featured_posts', false ) ) {
	return; // Return if not archive
}

?>

<?php if ( is_category() && get_theme_mod( 'tfm_featured_posts', false ) )  :

// meta vars
$meta_var['avatar'] = get_theme_mod( 'tfm_featured_posts_entry_meta_avatar', false ) ? 'has-avatar' : '';
$meta_var['author'] = get_theme_mod( 'tfm_featured_posts_entry_meta_author', false ) ? 'has-author' : '';
$meta_var['date'] = get_theme_mod( 'tfm_featured_posts_entry_meta_date', false ) ? 'has-date' : '';
$meta_var['comment_count'] = get_theme_mod( 'tfm_featured_posts_entry_meta_comment_count', false ) ? 'has-comment-count' : '';
$meta_var['read_time'] = get_theme_mod( 'tfm_featured_posts_entry_meta_read_time', false ) ? 'has-tfm-read-time' : '';
$meta_var['by'] = get_theme_mod( 'tfm_featured_posts_entry_meta_by', false ) ? 'has-by' : '';

$meta_vars = join( ' ', $meta_var );


// SQL Query vars

$category = get_queried_object();
$cat = 'category_featured' === get_theme_mod( 'tfm_featured_posts_query', 'category_featured' ) || 'in_category' === get_theme_mod( 'tfm_featured_posts_query', 'category_featured' ) ? $category->term_id : '';
$post_num = get_theme_mod( 'tfm_featured_posts_query_num', 3 );
$sort_order = get_theme_mod( 'tfm_featured_posts_query_sort_order', 'desc' );
$meta_key = 'category_featured' === get_theme_mod( 'tfm_featured_posts_query', 'category_featured' ) || 'any_featured' === get_theme_mod( 'tfm_featured_posts_query', 'category_featured' ) ? 'tfm_featured_post' : '';

// WP Query

$query_args = array(
    'post_type'      => 'post',
    'posts_per_page' => $post_num,
    'cat' => $cat,
    'meta_key' => $meta_key, // Featured Posts
	'meta_value' => 1,
	'order' => $sort_order,
	'ignore_sticky_posts' => 1,
    'post_status' => array(      
				'publish', // A published post or page.
				),

	);

	$posts_query = new WP_Query( $query_args );

    if( $posts_query->have_posts( ) ) :

    $post_count = $posts_query->found_posts > $post_num ? $post_num : $posts_query->found_posts;

    $count = 0;

    // Open the posts wrapper

    $html .= '<div class="tfm-featured-posts posts-' . $post_count . '">';

    // Title

    if ( '' !== get_theme_mod( 'tfm_featured_posts_title', '' ) ) {

	    $html .= '<h5>' . esc_html( get_theme_mod( 'tfm_featured_posts_title', '' ) ) . '</h5>';

	}

	$html .= '<div class="post-grid cols-3">';

    ?>
 
    <?php 

    /* Start the Loop */

    while ( $posts_query->have_posts( ) ) : $posts_query->the_post(); ?>

    	<?php

    	$count++;

    	$html .= '<article class="article tfm-featured-posts-article ' . $meta_vars . '">';

    	// Thumbnail

    	if ( has_post_thumbnail() && get_theme_mod( 'tfm_featured_posts_thumbnail', false ) ) :

    		$html .= '<div class="post-thumbnail">';
			$html .= '<a href="' . esc_url( get_permalink() ) . '">';
			$html .= get_the_post_thumbnail( '', 'thumbnail' );
			$html .= '</a>';
			$html .= '</div>';


    	endif;

    	// Entry header open

    	$html .= '<div class="entry-header">';

    	// Before title meta

    	if ( get_theme_mod( 'tfm_featured_posts_entry_meta_category', false ) ) {

    		$category_slug = array_slice( get_the_category(), 0, 1 ); // Only display a single category slug

    		$html .= '<div class="entry-meta before-title">';
    		$html .= '<ul class="post-categories-meta">';

	    	foreach ($category_slug as $the_category) {
				
				$html .= '<li class="cat-slug-' . esc_attr( $the_category->slug ) . ' cat-id-' . esc_attr( $the_category->cat_ID ) . '">';
				$html .= '<span class="screen-reader-text">' . esc_html__('Posted in', 'tfm-theme-boost' ) . '</span><i dir="ltr">' . esc_html__('in', 'tfm-theme-boost' ) . '</i> ';
				$html .= '<a href="' . get_category_link( $the_category->cat_ID ) . '" class="cat-link-' . esc_attr( $the_category->cat_ID ) . '">' . esc_html( $the_category->cat_name ) . '</a></li>';

				break; // Just in case, lets break after the first iteration

			}

			$html .= '</ul>';
			$html .= '</div>';

	    	}

    	// Entry title

    	$html .= '<a href="' . esc_url( get_permalink() ) . '" rel="bookmark" class="entry-title-link">' . get_the_title( ) . '</a>';

    	// After title meta

    	if ( get_theme_mod( 'tfm_featured_posts_entry_meta_avatar', false ) || get_theme_mod( 'tfm_featured_posts_entry_meta_author', false ) || get_theme_mod( 'tfm_featured_posts_entry_meta_date', false ) || get_theme_mod( 'tfm_featured_posts_entry_meta_comment_count', false ) || get_theme_mod( 'tfm_featured_posts_entry_meta_read_time', false ) ) {

	    	$html .= '<div class="entry-meta after-title">';

	    	$html .= '<ul class="after-title-meta">';

	    	// avatar

	    	if ( get_theme_mod( 'tfm_featured_posts_entry_meta_avatar', false ) ) {

	    		$html .= '<li class="entry-meta-avatar"><a href="' . get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ) . '">' . get_avatar( get_the_author_meta('ID'), 30 ) . '</a></li>';

	    	}

	    	// author
	    	
	    	if ( get_theme_mod( 'tfm_featured_posts_entry_meta_author', false ) ) {

	    		$html .= '<li class="entry-meta-author"><span class="screen-reader-text">Posted</span><i dir="ltr">' . esc_html__('by', 'tfm-theme-boost' ) . '</i> <a href="' . get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ) . '">' . get_the_author() . '</a></li>';

	    	}

	    	// author
	    	
	    	if ( get_theme_mod( 'tfm_featured_posts_entry_meta_date', false ) ) {

	    		$html .= '<li class="entry-meta-date"><time datetime="' . get_the_date( 'Y-m-d' ) . '">' . get_the_time( get_option( 'date_format' ) ) . '</time></li>';

	    	}

	    	// comment count
	    	
	    	if ( get_theme_mod( 'tfm_featured_posts_entry_meta_comment_count', false ) ) {

	    		$comment_string = (int)get_comments_number() === 1 ? esc_html__( ' Comment', 'tfm-theme-boost' ) : esc_html__( ' Comments', 'tfm-theme-boost' );

				$html .= '<li class="entry-meta-comment-count">' . get_comments_number() . '<span>' . esc_attr( $comment_string ) . '</span></li>';


	    	}

	    	// comment count
	    	
	    	if ( function_exists( 'tfm_read_time' ) && get_theme_mod( 'tfm_featured_posts_entry_meta_read_time', false ) ) {

				$html .= tfm_read_time( $forced_request = true, $return = true );


	    	}

	    	// Close after-title list and entry meta wrapper
							
			$html .= '</ul>';
	    	$html .= '</div>';

	    } // Endif entry meta

    	// Close entry header
    	$html .= '</div>';

    	$html .= '</article>';


	endwhile;

	// Close post grid

	$html .= '</div>';

	// Close featured posts wrapper

	$html .= '</div>';

    endif;

    wp_reset_postdata(); // Always reset

 	?>


<?php endif; ?>