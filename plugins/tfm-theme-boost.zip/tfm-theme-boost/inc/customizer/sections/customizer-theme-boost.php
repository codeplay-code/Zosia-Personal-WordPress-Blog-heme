<?php

function tfm_customize_register_theme_boost( $wp_customize ) {

	$wp_customize->add_panel( 'tfm_theme_boost', array(
		  'title'    => esc_html__( 'TFM: Theme Boost', 'tfm-theme-boost' ),
		  'priority' => 160,
		  ) );

	$wp_customize->add_section( 'tfm_performance_seo_settings', array(
			'title'    => esc_html__( 'SEO &amp; Misc. Settings', 'tfm-theme-boost' ),
			'priority' => 160,
			'panel' => 'tfm_theme_boost',
		) );

	// Image quality
	$wp_customize->add_setting( 'tfm_image_quality', array(
		'default'           => '82',
		'sanitize_callback' => 'absint',
	) );

	$wp_customize->add_control( 'tfm_image_quality', array(
		'label'       => esc_html__( 'Image Quality (%)', 'tfm-theme-boost' ),
		'description' => esc_html__( 'Lower quality provides a smaller file size and faster loading pages. Remember to regenerate your thumbnails after changing this setting. WordPress default setting is "82"', 'tfm-theme-boost' ),
		'section'     => 'tfm_performance_seo_settings',
		'type'        => 'number',
		'input_attrs' => array(
		        'min'   => 0,
		        'max' => 100,
		        'step' => 1,
		    ),
	) );

	// Human entry date
	$wp_customize->add_setting( 'tfm_human_entry_date', array(
		'default'           => false,
		'sanitize_callback' => 'tfm_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'tfm_human_entry_date', array(
		'label'       => esc_html__( 'Human Readable Entry Date', 'tfm-theme-boost' ),
		'section'     => 'tfm_performance_seo_settings',
		'type'        => 'checkbox',
	) );

	// Human entry date
	$wp_customize->add_setting( 'tfm_human_comment_date', array(
		'default'           => false,
		'sanitize_callback' => 'tfm_sanitize_checkbox',
	) );

	$wp_customize->add_control( 'tfm_human_comment_date', array(
		'label'       => esc_html__( 'Human Readable Comment Date', 'tfm-theme-boost' ),
		'section'     => 'tfm_performance_seo_settings',
		'type'        => 'checkbox',
	) );

}

add_action( 'customize_register', 'tfm_customize_register_theme_boost' );