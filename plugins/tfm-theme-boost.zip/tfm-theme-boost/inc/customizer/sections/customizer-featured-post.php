<?php

function tfm_customize_register_featured_posts_settings( $wp_customize ) {

	if ( apply_filters( 'tfm_theme_supports_featured_post_misc_colors', true )) :

		// Featured post colour settings

		$wp_customize->add_setting( 'tfm_featured_post_background', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_featured_post_background', array(
	      'section' => tfm_get_theme_textdomain() . '_misc_colors',
	      'label'   => esc_html__( 'Featured Post Background', 'tfm-theme-boost' ),
	    ) ) );

	    $wp_customize->add_setting( 'tfm_featured_post_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_featured_post_color', array(
	      'section' => tfm_get_theme_textdomain() . '_misc_colors',
	      'label'   => esc_html__( 'Featured Post Text Color', 'tfm-theme-boost' ),
	    ) ) );

	endif;

}

add_action( 'customize_register', 'tfm_customize_register_featured_posts_settings', 100 );