<?php

$tfm_theme_boost_options = get_option( 'tfm_theme_boost_option_name' );

if ( ! isset($tfm_theme_boost_options['tfm_featured_posts'])) {
	return;
}

function tfm_customize_register_featured_posts( $wp_customize ) {

	if ( apply_filters( 'tfm_theme_supports_featured_posts', false ) ) {

		$wp_customize->add_section( 'tfm_featured_posts_settings', array(
				'title'    => esc_html__( 'TFM: Featured Posts', 'tfm-theme-boost' ),
				'priority' => 160,
			) );

		$wp_customize->add_setting( 'tfm_featured_posts', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_featured_posts', array(
			'label'       => esc_html__( 'Display Featured Posts', 'tfm-theme-boost' ),
			'section'     => 'tfm_featured_posts_settings',
			'type'        => 'checkbox',
		) );

		$wp_customize->add_setting( 'tfm_featured_posts_sash', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_featured_posts_sash', array(
			'label'       => esc_html__( 'Display Featured Post Sash', 'tfm-theme-boost' ),
			'section'     => 'tfm_featured_posts_settings',
			'type'        => 'checkbox',
		) );

		$wp_customize->add_setting( 'tfm_featured_posts_title', array(
			'default'           => '',
			'sanitize_callback' => 'tfm_sanitize_text',
		) );

		$wp_customize->add_control( 'tfm_featured_posts_title', array(
			'label'       => esc_html__( 'Title', 'tfm-theme-boost' ),
			'section'     => 'tfm_featured_posts_settings',
			'type'        => 'text',
		) );

		// Query settings

		$wp_customize->add_setting( 'tfm_featured_posts_query', array(
			'default'           => 'category_featured',
			'sanitize_callback' => 'tfm_sanitize_radio',
		) );

		$wp_customize->add_control( 'tfm_featured_posts_query', array(
			'label'       => esc_html__( 'Posts Query', 'tfm-theme-boost' ),
			'description' => esc_html__( 'Set featured posts in the settings panel for each post', 'tfm-theme-boost'),
			'section'     => 'tfm_featured_posts_settings',
			'type'        => 'radio',
			'choices'     => array(
				'category_featured' => esc_html__( 'Featured (in Category)', 'tfm-theme-boost' ),
				'any_featured' => esc_html__( 'Featured (Any)', 'tfm-theme-boost' ),
				'in_category' => esc_html__( 'Posts (in Category)', 'tfm-theme-boost'),
				'any' => esc_html__( 'Posts (Any)', 'tfm-theme-boost'),
			),
		) );

		$wp_customize->add_setting( 'tfm_featured_posts_query_sort_order', array(
			'default'           => 'desc',
			'sanitize_callback' => 'tfm_sanitize_radio',
		) );

		$wp_customize->add_control( 'tfm_featured_posts_query_sort_order', array(
			'label'       => esc_html__( 'Sort order', 'tfm-theme-boost' ),
			'section'     => 'tfm_featured_posts_settings',
			'type'        => 'radio',
			'choices'     => array(
				'desc' => esc_html__( 'Newest to Oldest', 'tfm-theme-boost' ),
				'asc' => esc_html__( 'Oldest to Newest', 'tfm-theme-boost' ),
			),
		) );

		$wp_customize->add_setting( 'tfm_featured_posts_query_num', array(
			'default'           => '3',
			'sanitize_callback' => 'absint',
		) );

		$wp_customize->add_control( 'tfm_featured_posts_query_num', array(
			'label'       => esc_html__( 'Number of posts', 'tfm-theme-boost' ),
			'section'     => 'tfm_featured_posts_settings',
			'type'        => 'number',
			'input_attrs' => array(
		        'min'   => 1,
		        'max'   => apply_filters( 'tfm_category_featured_max_posts', 3 ),
		    ),
		) );

		// End query settings

		$wp_customize->add_setting( 'tfm_featured_posts_thumbnail', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_featured_posts_thumbnail', array(
			'label'       => esc_html__( 'Thumbnail', 'tfm-theme-boost' ),
			'section'     => 'tfm_featured_posts_settings',
			'type'        => 'checkbox',
		) );

		$wp_customize->add_setting( 'tfm_featured_posts_entry_meta_category', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_featured_posts_entry_meta_category', array(
			'label'       => esc_html__( 'Category', 'tfm-theme-boost' ),
			'section'     => 'tfm_featured_posts_settings',
			'type'        => 'checkbox',
		) );

		if ( apply_filters( 'tfm_featured_posts_theme_supports_avatar', true ) ):

			$wp_customize->add_setting( 'tfm_featured_posts_entry_meta_avatar', array(
				'default'           => false,
				'sanitize_callback' => 'tfm_sanitize_checkbox',
			) );

			$wp_customize->add_control( 'tfm_featured_posts_entry_meta_avatar', array(
				'label'       => esc_html__( 'Avatar', 'tfm-theme-boost' ),
				'section'     => 'tfm_featured_posts_settings',
				'type'        => 'checkbox',
			) );

		endif;

		$wp_customize->add_setting( 'tfm_featured_posts_entry_meta_by', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_featured_posts_entry_meta_by', array(
			'label'       => esc_html__( '"by"', 'tfm-theme-boost' ),
			'section'     => 'tfm_featured_posts_settings',
			'type'        => 'checkbox',
		) );

		$wp_customize->add_setting( 'tfm_featured_posts_entry_meta_author', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_featured_posts_entry_meta_author', array(
			'label'       => esc_html__( 'Author', 'tfm-theme-boost' ),
			'section'     => 'tfm_featured_posts_settings',
			'type'        => 'checkbox',
		) );

		$wp_customize->add_setting( 'tfm_featured_posts_entry_meta_date', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_featured_posts_entry_meta_date', array(
			'label'       => esc_html__( 'Date', 'tfm-theme-boost' ),
			'section'     => 'tfm_featured_posts_settings',
			'type'        => 'checkbox',
		) );

		$wp_customize->add_setting( 'tfm_featured_posts_entry_meta_comment_count', array(
			'default'           => false,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_featured_posts_entry_meta_comment_count', array(
			'label'       => esc_html__( 'Comment Count', 'tfm-theme-boost' ),
			'section'     => 'tfm_featured_posts_settings',
			'type'        => 'checkbox',
		) );

		if ( function_exists('tfm_read_time')) :

			$wp_customize->add_setting( 'tfm_featured_posts_entry_meta_read_time', array(
				'default'           => false,
				'sanitize_callback' => 'tfm_sanitize_checkbox',
			) );

			$wp_customize->add_control( 'tfm_featured_posts_entry_meta_read_time', array(
				'label'       => esc_html__( 'Read Time', 'tfm-theme-boost' ),
				'section'     => 'tfm_featured_posts_settings',
				'type'        => 'checkbox',
			) );

		endif;


		// Colour settings

		$wp_customize->add_setting('tfm_featured_posts_colors_separator', array(
			'default'           => '',
			'sanitize_callback' => 'esc_html',
		));
		$wp_customize->add_control(new Tfm_Separator_Custom_Control($wp_customize, 'tfm_featured_posts_colors_separator', array(
			'settings'		=> 'tfm_featured_posts_colors_separator',
			'section'  		=> 'tfm_featured_posts_settings',
		)));

		$wp_customize->add_setting( 'tfm_featured_posts_background', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_featured_posts_background', array(
	      'section' => 'tfm_featured_posts_settings',
	      'label'   => esc_html__( 'Background Color', 'tfm-theme-boost' ),
	    ) ) );

	    $wp_customize->add_setting( 'tfm_featured_posts_heading_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_featured_posts_heading_color', array(
	      'section' => 'tfm_featured_posts_settings',
	      'label'   => esc_html__( 'Heading Color', 'tfm-theme-boost' ),
	    ) ) );

	    $wp_customize->add_setting( 'tfm_featured_posts_link_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_featured_posts_link_color', array(
	      'section' => 'tfm_featured_posts_settings',
	      'label'   => esc_html__( 'Link Color', 'tfm-theme-boost' ),
	    ) ) );

	    $wp_customize->add_setting( 'tfm_featured_posts_entry_meta_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_featured_posts_entry_meta_color', array(
	      'section' => 'tfm_featured_posts_settings',
	      'label'   => esc_html__( 'Entry Meta Color', 'tfm-theme-boost' ),
	    ) ) );

	    $wp_customize->add_setting( 'tfm_featured_posts_entry_meta_misc_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_featured_posts_entry_meta_misc_color', array(
	      'section' => 'tfm_featured_posts_settings',
	      'label'   => esc_html__( 'Misc. Elements Color', 'tfm-theme-boost' ),
	    ) ) );

	} // Endif theme support

}

add_action( 'customize_register', 'tfm_customize_register_featured_posts' );