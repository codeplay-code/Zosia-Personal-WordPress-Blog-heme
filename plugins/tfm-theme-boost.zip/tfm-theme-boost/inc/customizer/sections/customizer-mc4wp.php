<?php

function tfm_customize_register_mc4wp( $wp_customize ) {

	// Add MC4WP setting to theme footer customizer panel

		if ( class_exists( 'MC4WP_Form_Widget' ) ) {

			// Footer settings

			$wp_customize->add_setting('tfm_mc4wp_footer_widget_separator', array(
				'default'           => '',
				'sanitize_callback' => 'esc_html',
			));
			$wp_customize->add_control(new Tfm_Separator_Custom_Control($wp_customize, 'tfm_mc4wp_footer_widget_separator', array(
				'settings'		=> 'tfm_mc4wp_footer_widget_separator',
				'section'  		=> tfm_get_theme_textdomain() . '_footer_settings',
			)));

			// Footer settings

			$wp_customize->add_setting( 'tfm_mc4wp_footer_widget', array(
				'default'           => false,
				'sanitize_callback' => 'tfm_sanitize_checkbox',
			) );

			$wp_customize->add_control( 'tfm_mc4wp_footer_widget', array(
				'label'       => esc_html__( 'Display MailChimp Form in Footer Area', 'tfm-theme-boost' ),
				'section'     => tfm_get_theme_textdomain() . '_footer_settings',
				'type'        => 'checkbox',
				'priority'    => 100,
			) );

			$wp_customize->add_setting( 'tfm_mc4wp_footer_widget_form_id', array(
				'default'           => '',
				'sanitize_callback' => 'tfm_sanitize_text',
			) );

			$wp_customize->add_control( 'tfm_mc4wp_footer_widget_form_id', array(
				'label'       => esc_html__( 'MailChimp Form ID *optional', 'tfm-theme-boost' ),
				'description' => esc_html__( 'If you have more than one form enter the ID of the form you want to display', 'tfm-theme-boost'),
				'section'     => tfm_get_theme_textdomain() . '_footer_settings',
				'type'        => 'text',
				'priority'    => 100,
			) );

			$wp_customize->add_setting( 'tfm_mc4wp_footer_widget_title', array(
				'default'           => '',
				'sanitize_callback' => 'tfm_sanitize_text',
			) );

			$wp_customize->add_control( 'tfm_mc4wp_footer_widget_title', array(
				'label'       => esc_html__( 'MailChimp Form Title', 'tfm-theme-boost' ),
				'section'     => tfm_get_theme_textdomain() . '_footer_settings',
				'type'        => 'text',
				'priority'    => 100,
			) );

			// mc4p background image

			$wp_customize->add_setting('tfm_before_footer_background_image', array(
				'default'           => '',
				'sanitize_callback' => 'tfm_sanitize_image',
			));

			$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'tfm_before_footer_background_image', array(
		               'label'      => esc_html__( 'MailChimp Form Background Image', 'tfm-theme-boost' ),
		               'section'    => tfm_get_theme_textdomain() . '_footer_settings',
		               'priority' => 100,
		           )
		       )
		   );

			// Footer Colours

			$wp_customize->add_setting('tfm_before_footer_colors_separator', array(
				'default'           => '',
				'sanitize_callback' => 'esc_html',
			));
			$wp_customize->add_control(new Tfm_Separator_Custom_Control($wp_customize, 'tfm_before_footer_colors_separator', array(
				'settings'		=> 'tfm_before_footer_colors_separator',
				'section'  		=> tfm_get_theme_textdomain() . '_footer_colors',
			)));

			$wp_customize->add_setting( 'tfm_before_footer_background', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_before_footer_background', array(
		      'section' => tfm_get_theme_textdomain() . '_footer_colors',
		      'label'   => esc_html__( 'MailChimp Form Background', 'tfm-theme-boost' ),
		    ) ) );

		    $wp_customize->add_setting( 'tfm_before_footer_title_color', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_before_footer_title_color', array(
		      'section' => tfm_get_theme_textdomain() . '_footer_colors',
		      'label'   => esc_html__( 'MailChimp Form Title Color', 'tfm-theme-boost' ),
		    ) ) );

		    $wp_customize->add_setting( 'tfm_before_footer_text_color', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_before_footer_text_color', array(
		      'section' => tfm_get_theme_textdomain() . '_footer_colors',
		      'label'   => esc_html__( 'MailChimp Form Text Color', 'tfm-theme-boost' ),
		    ) ) );

		     $wp_customize->add_setting( 'tfm_before_footer_button_background', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_before_footer_button_background', array(
		      'section' => tfm_get_theme_textdomain() . '_footer_colors',
		      'label'   => esc_html__( 'MailChimp Form Button Color', 'tfm-theme-boost' ),
		    ) ) );

		    $wp_customize->add_setting( 'tfm_before_footer_button_color', array(
				'default'           => '',
				'transport' => 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
			) );

			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_before_footer_button_color', array(
		      'section' => tfm_get_theme_textdomain() . '_footer_colors',
		      'label'   => esc_html__( 'MailChimp Form Button Text Color', 'tfm-theme-boost' ),
		    ) ) );

		}

}

add_action( 'customize_register', 'tfm_customize_register_mc4wp', 100 );