<?php

$tfm_theme_boost_options = get_option( 'tfm_theme_boost_option_name' );

if ( ! isset($tfm_theme_boost_options['tfm_ads'])) {
	return;
}

function tfm_customize_register_adverts( $wp_customize ) {

	// ========================================================
		// Adverts
		// ========================================================

		$wp_customize->add_panel( 'tfm_adverts', array(
		  'title'    => esc_html__( 'TFM: Advertising', 'tfm-theme-boost' ),
		  'description' => esc_html__( 'Add banners and widgets', 'tfm-theme-boost' ),
		  'priority' => 160,
		  ) );

		/*****************
		 * After header
		 ****************/

		$wp_customize->add_section( 'tfm_ad_after_header', array(
			'title'    => esc_html__( 'After header Advert', 'tfm-theme-boost' ),
			'panel' => 'tfm_adverts',
			'priority' => 160,
		) );

		$wp_customize->add_setting('tfm_ad_after_header_image', array(
			'default'           => '',
			'sanitize_callback' => 'tfm_sanitize_image',
		));

		$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'tfm_ad_after_header_image', array(
	               'label'      => esc_html__( 'Image', 'tfm-theme-boost' ),
	               'section'    => 'tfm_ad_after_header',
	           )
	       )
	   );

		$wp_customize->add_setting('tfm_ad_after_header_image_2x', array(
			'default'           => '',
			'sanitize_callback' => 'tfm_sanitize_image',
		));

		$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'tfm_ad_after_header_image_2x', array(
	               'label'      => esc_html__( 'Image (High Res)', 'tfm-theme-boost' ),
	               'description' => esc_html__( 'Optional Image for High Resolution displays', 'tfm-theme-boost' ),
	               'section'    => 'tfm_ad_after_header',
	           )
	       )
	   );

		$wp_customize->add_setting( 'tfm_ad_after_header_url', array(
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
		) );

		$wp_customize->add_control( 'tfm_ad_after_header_url', array(
			'label'       => esc_html__( 'URL', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_after_header',
			'type'        => 'text',
		) );

		$wp_customize->add_setting( 'tfm_ad_after_header_code', array(
			'default'           => '',
			'sanitize_callback' => '', // Do not escape
		) );

		$wp_customize->add_control( 'tfm_ad_after_header_code', array(
			'label'       => esc_html__( 'Code', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_after_header',
			'type'        => 'textarea',
		) );

		// Locations

		$wp_customize->add_setting( 'tfm_ad_after_header_display_home', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_ad_after_header_display_home', array(
			'label'       => esc_html__( 'Display on Homepage', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_after_header',
			'type'        => 'checkbox',
		) );

		$wp_customize->add_setting( 'tfm_ad_after_header_display_blog', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_ad_after_header_display_blog', array(
			'label'       => esc_html__( 'Display on Blog Page', 'tfm-theme-boost' ),
			'description' => esc_html__( '* If your Posts Page is set to a page', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_after_header',
			'type'        => 'checkbox',
		) );

		$wp_customize->add_setting( 'tfm_ad_after_header_display_archive', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_ad_after_header_display_archive', array(
			'label'       => esc_html__( 'Display in Archive/Category', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_after_header',
			'type'        => 'checkbox',
		) );

		$wp_customize->add_setting( 'tfm_ad_after_header_display_single', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_ad_after_header_display_single', array(
			'label'       => esc_html__( 'Display on Single Posts', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_after_header',
			'type'        => 'checkbox',
		) );

		$wp_customize->add_setting( 'tfm_ad_after_header_display_page', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_ad_after_header_display_page', array(
			'label'       => esc_html__( 'Display on Pages', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_after_header',
			'type'        => 'checkbox',
		) );

		if ( class_exists('WooCommerce') ) {

			$wp_customize->add_setting( 'tfm_ad_after_header_display_shop', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_ad_after_header_display_shop', array(
			'label'       => esc_html__( 'Display on Shop', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_after_header',
			'type'        => 'checkbox',
		) );

		}

		$wp_customize->add_setting( 'tfm_ad_after_header_display_mobile', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_ad_after_header_display_mobile', array(
			'label'       => esc_html__( 'Display on Mobile', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_after_header',
			'type'        => 'checkbox',
		) );

		 // Add Setting
		$wp_customize->add_setting( 'tfm_ad_after_header_background', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_ad_after_header_background', array(
	      'section' => 'tfm_ad_after_header',
	      'label'   => esc_html__( 'Background Color', 'tfm-theme-boost' ),
	    ) ) );

	    // Add Setting
		$wp_customize->add_setting( 'tfm_ad_after_header_border_color', array(
			'default'           => '',
			'transport' => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		) );

		// Control Options
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'tfm_ad_after_header_border_color', array(
	      'section' => 'tfm_ad_after_header',
	      'label'   => esc_html__( 'Border Color', 'tfm-theme-boost' ),
	    ) ) );

		/*****************
		 * Site Header
		 ****************/

		$wp_customize->add_section( 'tfm_ad_site_header', array(
			'title'    => esc_html__( 'Site header Advert', 'tfm-theme-boost' ),
			'panel' => 'tfm_adverts',
			'priority' => 160,
		) );

		$wp_customize->add_setting('tfm_ad_site_header_image', array(
			'default'           => '',
			'sanitize_callback' => 'tfm_sanitize_image',
		));

		$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'tfm_ad_site_header_image', array(
	               'label'      => esc_html__( 'Image', 'tfm-theme-boost' ),
	               'section'    => 'tfm_ad_site_header',
	           )
	       )
	   );

		$wp_customize->add_setting('tfm_ad_site_header_image_2x', array(
			'default'           => '',
			'sanitize_callback' => 'tfm_sanitize_image',
		));

		$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'tfm_ad_site_header_image_2x', array(
	               'label'      => esc_html__( 'Image (High Res)', 'tfm-theme-boost' ),
	               'description' => esc_html__( 'Optional Image for High Resolution displays', 'tfm-theme-boost' ),
	               'section'    => 'tfm_ad_site_header',
	           )
	       )
	   );

		$wp_customize->add_setting( 'tfm_ad_site_header_url', array(
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
		) );

		// Control Options
		$wp_customize->add_control( 'tfm_ad_site_header_url', array(
			'label'       => esc_html__( 'URL', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_site_header',
			'type'        => 'text',
		) );

		$wp_customize->add_setting( 'tfm_ad_site_header_code', array(
			'default'           => '',
			'sanitize_callback' => '', // Do not escape
		) );

		$wp_customize->add_control( 'tfm_ad_site_header_code', array(
			'label'       => esc_html__( 'Code', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_site_header',
			'type'        => 'textarea',
		) );

		// Locations

		$wp_customize->add_setting( 'tfm_ad_site_header_display_home', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_ad_site_header_display_home', array(
			'label'       => esc_html__( 'Display on Homepage', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_site_header',
			'type'        => 'checkbox',
		) );

		$wp_customize->add_setting( 'tfm_ad_site_header_display_blog', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_ad_site_header_display_blog', array(
			'label'       => esc_html__( 'Display on Blog Page', 'tfm-theme-boost' ),
			'description' => esc_html__( '* If your Posts Page is set to a page', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_site_header',
			'type'        => 'checkbox',
		) );

		$wp_customize->add_setting( 'tfm_ad_site_header_display_archive', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_ad_site_header_display_archive', array(
			'label'       => esc_html__( 'Display in Archive/Category', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_site_header',
			'type'        => 'checkbox',
		) );

		$wp_customize->add_setting( 'tfm_ad_site_header_display_single', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_ad_site_header_display_single', array(
			'label'       => esc_html__( 'Display on Single Posts', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_site_header',
			'type'        => 'checkbox',
		) );

		$wp_customize->add_setting( 'tfm_ad_site_header_display_page', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_ad_site_header_display_page', array(
			'label'       => esc_html__( 'Display on Pages', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_site_header',
			'type'        => 'checkbox',
		) );

		if ( class_exists('WooCommerce') ) {

			$wp_customize->add_setting( 'tfm_ad_site_header_display_shop', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_ad_site_header_display_shop', array(
			'label'       => esc_html__( 'Display on Shop', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_site_header',
			'type'        => 'checkbox',
		) );

		}

		/*****************
		 * before footer
		 ****************/

		$wp_customize->add_section( 'tfm_ad_before_footer', array(
			'title'    => esc_html__( 'Before Footer Advert', 'tfm-theme-boost' ),
			'panel' => 'tfm_adverts',
			'priority' => 160,
		) );

		$wp_customize->add_setting('tfm_ad_before_footer_image', array(
			'default'           => '',
			'sanitize_callback' => 'tfm_sanitize_image',
		));

		$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'tfm_ad_before_footer_image', array(
	               'label'      => esc_html__( 'Image', 'tfm-theme-boost' ),
	               'section'    => 'tfm_ad_before_footer',
	           )
	       )
	   );

		$wp_customize->add_setting('tfm_ad_before_footer_image_2x', array(
			'default'           => '',
			'sanitize_callback' => 'tfm_sanitize_image',
		));

		$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'tfm_ad_before_footer_image_2x', array(
	               'label'      => esc_html__( 'Image (High Res)', 'tfm-theme-boost' ),
	               'description' => esc_html__( 'Optional Image for High Resolution displays', 'tfm-theme-boost' ),
	               'section'    => 'tfm_ad_before_footer',
	           )
	       )
	   );

		$wp_customize->add_setting( 'tfm_ad_before_footer_url', array(
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
		) );

		$wp_customize->add_control( 'tfm_ad_before_footer_url', array(
			'label'       => esc_html__( 'URL', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_before_footer',
			'type'        => 'text',
		) );

		$wp_customize->add_setting( 'tfm_ad_before_footer_code', array(
			'default'           => '',
			'sanitize_callback' => '', // Do not escape
		) );

		$wp_customize->add_control( 'tfm_ad_before_footer_code', array(
			'label'       => esc_html__( 'Code', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_before_footer',
			'type'        => 'textarea',
		) );

		// Locations

		$wp_customize->add_setting( 'tfm_ad_before_footer_display_home', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_ad_before_footer_display_home', array(
			'label'       => esc_html__( 'Display on Homepage', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_before_footer',
			'type'        => 'checkbox',
		) );

		$wp_customize->add_setting( 'tfm_ad_before_footer_display_blog', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_ad_before_footer_display_blog', array(
			'label'       => esc_html__( 'Display on Blog Page', 'tfm-theme-boost' ),
			'description' => esc_html__( '* If your Posts Page is set to a page', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_before_footer',
			'type'        => 'checkbox',
		) );

		$wp_customize->add_setting( 'tfm_ad_before_footer_display_archive', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_ad_before_footer_display_archive', array(
			'label'       => esc_html__( 'Display in Archive/Category', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_before_footer',
			'type'        => 'checkbox',
		) );

		$wp_customize->add_setting( 'tfm_ad_before_footer_display_single', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_ad_before_footer_display_single', array(
			'label'       => esc_html__( 'Display on Single Posts', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_before_footer',
			'type'        => 'checkbox',
		) );

		$wp_customize->add_setting( 'tfm_ad_before_footer_display_page', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_ad_before_footer_display_page', array(
			'label'       => esc_html__( 'Display on Pages', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_before_footer',
			'type'        => 'checkbox',
		) );

		if ( class_exists('WooCommerce') ) {

			$wp_customize->add_setting( 'tfm_ad_before_footer_display_shop', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_ad_before_footer_display_shop', array(
			'label'       => esc_html__( 'Display on Shop', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_before_footer',
			'type'        => 'checkbox',
		) );

		}

		$wp_customize->add_setting( 'tfm_ad_before_footer_display_mobile', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_ad_before_footer_display_mobile', array(
			'label'       => esc_html__( 'Display on Mobile', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_before_footer',
			'type'        => 'checkbox',
		) );

		if ( class_exists('WooCommerce') ) {

			$wp_customize->add_setting( 'tfm_ad_before_footer_display_shop', array(
			'default'           => true,
			'sanitize_callback' => 'tfm_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'tfm_ad_before_footer_display_shop', array(
			'label'       => esc_html__( 'Display on Shop', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_before_footer',
			'type'        => 'checkbox',
		) );

		}

		/*****************
		 * After header
		 ****************/

		$wp_customize->add_section( 'tfm_ad_head_tag', array(
			'title'    => esc_html__( 'Head Tag Code (AutoAds)', 'tfm-theme-boost' ),
			'panel' => 'tfm_adverts',
			'priority' => 160,
		) );

		$wp_customize->add_setting( 'tfm_ad_head_tag_code', array(
			'default'           => '',
			'sanitize_callback' => '', // Do not escape
		) );

		$wp_customize->add_control( 'tfm_ad_head_tag_code', array(
			'label'       => esc_html__( 'Code', 'tfm-theme-boost' ),
			'section'     => 'tfm_ad_head_tag',
			'type'        => 'textarea',
		) );

}

add_action( 'customize_register', 'tfm_customize_register_adverts' );