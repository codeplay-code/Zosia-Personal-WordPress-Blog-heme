<?php

/**
 * 340 Media: Custom Meta Boxes
 *
 * @since 1.0
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

define( 'TFM_META_BOXES__PLUGIN_DIR', plugin_dir_path( __FILE__ ) );


// ========================================================
// Add single post meta box settings
// ========================================================

if ( ! function_exists( 'tfm_custom_meta_box' ) ) {

	function tfm_custom_meta_box() {

		// Get theme name
		$theme = wp_get_theme();
		$theme_name =  $theme->get( 'Name' ) . ': ';

		add_meta_box(
			'tfm_single_options',
			ucfirst(esc_attr($theme_name)) . esc_html__( 'Post Options', 'tfm-theme-boost' ),
			'tfm_meta_box_callback',
			'post',
			'side',
			'low'
			);

		add_meta_box(
			'tfm_simple_ratings',
			ucfirst(esc_attr($theme_name)) . esc_html__( 'Ratings', 'tfm-theme-boost' ),
			'tfm_ratings_meta_box_callback',
			'post',
			'side',
			'low'
			);

		add_meta_box(
			'tfm_page_options',
			ucfirst(esc_attr($theme_name)) . esc_html__( 'Page Options', 'tfm-theme-boost' ),
			'tfm_page_meta_box_callback',
			'page',
			'side',
			'low'
			);

	}
}

add_action( 'add_meta_boxes', 'tfm_custom_meta_box' );

// ========================================================
// Post meta callback
// ========================================================

if ( ! function_exists( 'tfm_meta_box_callback' ) ) {

	function tfm_meta_box_callback( $post ) {

		wp_nonce_field(basename( __FILE__ ), 'tfm_post_meta_nonce' );

		// ========================================================
		// Select override global post style
		// ========================================================
		echo '<p><label for="tfm_single_post_style">' . esc_html__( 'Single Post style', 'tfm-theme-boost' ) . '</label></p>';
		echo '<p><select name="tfm_single_post_style">';

		$values = apply_filters( 'tfm_theme_boost_meta_box_single_post_styles', array(
			'global' => esc_html__( 'Use Global Setting', 'tfm-theme-boost' ),
			'default' => esc_html__( 'Default', 'tfm-theme-boost' ),
			'default-alt' => esc_html__( 'Default Alt.', 'tfm-theme-boost' ),
			'cover' => esc_html__( 'Cover', 'tfm-theme-boost' ),
			'hero-default' => esc_html__( 'Hero', 'tfm-theme-boost' ),
			'hero-cover' => esc_html__( 'Hero Cover', 'tfm-theme-boost' ),
		));

		foreach ($values as $key => $value ) {
			
			if ( $key == get_post_meta($post->ID, 'tfm_single_post_style', true ) ) {
				echo '<option selected value="' . esc_attr( $key ) . '">' . esc_html( $value ) . '</option>';
			} else {
				echo '<option value="' . esc_attr( $key ) . '">' . esc_html( $value ) . '</option>';
			}
		}

		echo '</select></p>';

		// ========================================================
		// Select override global sidebar setting (single)
		// ========================================================
		echo '<p><label for="tfm_single_post_sidebar">' . esc_html__( 'Single Sidebar', 'tfm-theme-boost' ) . '</label></p>';
		echo '<p><select name="tfm_single_post_sidebar">';

		$values = apply_filters( 'tfm_theme_boost_meta_box_sidebar', array(
			'global' => esc_html__( 'Use Global Setting', 'tfm-theme-boost' ),
			'has-sidebar' => esc_html__( 'Enable Sidebar', 'tfm-theme-boost' ),
			'disabled-sidebar' => esc_html__( 'Disable Sidebar', 'tfm-theme-boost' ),
		));

		foreach ($values as $key => $value ) {
			
			if ( $key == get_post_meta($post->ID, 'tfm_single_post_sidebar', true ) ) {
				echo '<option selected value="' . esc_attr( $key ) . '">' . esc_html( $value ) . '</option>';
			} else {
				echo '<option value="' . esc_attr( $key ) . '">' . esc_html( $value ) . '</option>';
			}
		}

		echo '</select></p>';

		// ========================================================
		// Thumbnail aspect ratio
		// ========================================================

		echo '<p><label for="tfm_single_post_thumbnail_size">' . esc_html__( 'Thumbnail Aspect Ratio', 'tfm-theme-boost' ) . '</label></p>';
		echo '<p><select name="tfm_single_post_thumbnail_size">';

		$values = apply_filters( 'tfm_theme_boost_meta_box_thumbnail', array(
			'global' => esc_html__( 'Use Global Setting', 'tfm-theme-boost' ),
			'wide' => esc_html__( 'Wide', 'tfm-theme-boost' ),
			'landscape' => esc_html__( 'Landscape', 'tfm-theme-boost' ),
			'portrait' => esc_html__( 'Portrait', 'tfm-theme-boost' ),
			'square' => esc_html__( 'Square', 'tfm-theme-boost' ),
			'hero' => esc_html__( 'Hero', 'tfm-theme-boost' ),
			'uncropped' => esc_html__( 'Uncropped', 'tfm-theme-boost' ),
		));

		foreach ($values as $key => $value ) {
			
			if ( $key == get_post_meta($post->ID, 'tfm_single_post_thumbnail_size', true ) ) {
				echo '<option selected value="' . esc_attr( $key ) . '">' . esc_html( $value ) . '</option>';
			} else {
				echo '<option value="' . esc_attr( $key ) . '">' . esc_html( $value ) . '</option>';
			}
		}

		echo '</select></p>';

		// ========================================================
		// Checkbox full width (single)
		// ========================================================

		if ( apply_filters( 'tfm_theme_supports_full_width_posts', true ) ) :

			$value = get_post_meta( $post->ID, 'tfm_single_full_width', true );

			echo '<label for="tfm_single_full_width" style="padding:10px 0 10px 0; display:inline-block">';
			if ($value == '') {
				echo ' <input id="tfm_single_full_width" name="tfm_single_full_width" type="checkbox" class="checkbox" style="height:20px;width:20px;border-radius:2px;margin-right:12px">';
			} else {
				echo ' <input id="tfm_single_full_width" name="tfm_single_full_width" type="checkbox" class="checkbox" checked="checked" style="height:20px;width:20px;border-radius:2px;margin-right:12px">';
			}
			echo esc_html__( 'Full Width', 'tfm-theme-boost' );
			echo '</label>';

		endif;

		// ========================================================
		// Checkbox disable featured image or media (single)
		// ========================================================
		$value = get_post_meta( $post->ID, 'tfm_disable_featured_media', true );

		echo '<label for="tfm_disable_featured_media" style="padding:10px 0 10px 0; display:inline-block">';
		if ($value == '') {
			echo ' <input id="tfm_disable_featured_media" name="tfm_disable_featured_media" type="checkbox" class="checkbox" style="height:20px;width:20px;border-radius:2px;margin-right:12px">';
		} else {
			echo ' <input id="tfm_disable_featured_media" name="tfm_disable_featured_media" type="checkbox" class="checkbox" checked="checked" style="height:20px;width:20px;border-radius:2px;margin-right:12px">';
		}
		echo esc_html__( 'Disable Single Featured Image', 'tfm-theme-boost' );
		echo '</label>';

		// ========================================================
		// Set as featured post
		// ========================================================
		$value = get_post_meta( $post->ID, 'tfm_featured_post', true );

		echo '<label for="tfm_featured_post" style="padding:10px 0 10px 0; display:inline-block">';
		if ($value == '') {
			echo ' <input id="tfm_featured_post" name="tfm_featured_post" type="checkbox" class="checkbox" style="height:20px;width:20px;border-radius:2px;margin-right:12px">';
		} else {
			echo ' <input id="tfm_featured_post" name="tfm_featured_post" type="checkbox" class="checkbox" checked="checked" style="height:20px;width:20px;border-radius:2px;margin-right:12px">';
		}
		echo esc_html__( 'Featured Post', 'tfm-theme-boost' );
		echo '</label>';

	}

}

// ========================================================
// Page meta callback
// ========================================================

if ( ! function_exists( 'tfm_page_meta_box_callback' ) ) {

	function tfm_page_meta_box_callback( $post ) {

		wp_nonce_field(basename( __FILE__ ), 'tfm_post_meta_nonce' );

		// ========================================================
		// Select override global sidebar setting (page)
		// ========================================================
		echo '<p><label for="tfm_single_page_sidebar"><b>' . esc_html__( 'Sidebar', 'tfm-theme-boost' ) . '</b></label></p>';
		echo '<p><select name="tfm_single_page_sidebar">';

		$values = apply_filters( 'tfm_theme_boost_meta_box_sidebar', array(
			'global' => esc_html__( 'Use Global Setting', 'tfm-theme-boost' ),
			'has-sidebar' => esc_html__( 'Enable Sidebar', 'tfm-theme-boost' ),
			'disabled-sidebar' => esc_html__( 'Disable Sidebar', 'tfm-theme-boost' ),
		));

		foreach ($values as $key => $value ) {
			
			if ( $key == get_post_meta($post->ID, 'tfm_single_page_sidebar', true ) ) {
				echo '<option selected value="' . esc_attr( $key ) . '">' . esc_html( $value ) . '</option>';
			} else {
				echo '<option value="' . esc_attr( $key ) . '">' . esc_html( $value ) . '</option>';
			}
		}

		echo '</select></p>';

	}

}


// ========================================================
// Ratings meta callback
// ========================================================

if ( ! function_exists( 'tfm_ratings_meta_box_callback' ) ) {

	function tfm_ratings_meta_box_callback( $post ) {

		wp_nonce_field(basename( __FILE__ ), 'tfm_post_meta_nonce' );

		// ========================================================
		// Ratings Range
		// ========================================================
		echo '<p><label for="tfm_simple_ratings_range">' . esc_html__( 'Range', 'tfm-theme-boost' ) . '</label></p>';
		echo '<p><select name="tfm_simple_ratings_range">';

		$values = array(
			'5' => esc_html__( '1 - 5', 'tfm-theme-boost' ),
			'10' => esc_html__( '1 - 10', 'tfm-theme-boost' ),
			'100' => esc_html__( '1 - 100', 'tfm-theme-boost' ),
		);

		foreach ($values as $key => $value ) {
			
			if ( $key == get_post_meta($post->ID, 'tfm_simple_ratings_range', true ) ) {
				echo '<option selected value="' . esc_attr( $key ) . '">' . esc_html( $value ) . '</option>';
			} else {
				echo '<option value="' . esc_attr( $key ) . '">' . esc_html( $value ) . '</option>';
			}
		}

		echo '</select></p>';

		// ========================================================
		// Ratings Total Score
		// ========================================================
		echo '<p><label for="tfm_simple_ratings_score">' . esc_html__( 'Total Score', 'tfm-theme-boost' ) . '</label></p>';

		$current_score = get_post_meta( $post->ID, 'tfm_simple_ratings_score', true );

		echo '<input type="text" name="tfm_simple_ratings_score" value="' . $current_score . '" />';


		// ========================================================
		// Stars
		// ========================================================
		$value = get_post_meta( $post->ID, 'tfm_star_rating', true );

		echo '<label for="tfm_star_rating" style="padding:10px 0 10px 0; display:block; margin-top:10px">';
		if ($value == '') {
			echo ' <input id="tfm_star_rating" name="tfm_star_rating" type="checkbox" class="checkbox" style="height:20px;width:20px;border-radius:2px;margin-right:12px">';
		} else {
			echo ' <input id="tfm_star_rating" name="tfm_star_rating" type="checkbox" class="checkbox" checked="checked" style="height:20px;width:20px;border-radius:2px;margin-right:12px">';
		}
		echo esc_html__( 'Star Rating', 'tfm-theme-boost' );
		echo '</label>';

		// ========================================================
		// Scale
		// ========================================================
		$value = get_post_meta( $post->ID, 'tfm_scale_rating', true );

		echo '<label for="tfm_scale_rating" style="padding:10px 0 10px 0; display:block">';
		if ($value == '') {
			echo ' <input id="tfm_scale_rating" name="tfm_scale_rating" type="checkbox" class="checkbox" style="height:20px;width:20px;border-radius:2px;margin-right:12px">';
		} else {
			echo ' <input id="tfm_scale_rating" name="tfm_scale_rating" type="checkbox" class="checkbox" checked="checked" style="height:20px;width:20px;border-radius:2px;margin-right:12px">';
		}
		echo esc_html__( 'Scale Rating', 'tfm-theme-boost' );
		echo '</label>';

		// ========================================================
		// Points
		// ========================================================
		$value = get_post_meta( $post->ID, 'tfm_points_rating', true );

		echo '<label for="tfm_points_rating" style="padding:10px 0 10px 0; display:block">';
		if ($value == '') {
			echo ' <input id="tfm_points_rating" name="tfm_points_rating" type="checkbox" class="checkbox" style="height:20px;width:20px;border-radius:2px;margin-right:12px">';
		} else {
			echo ' <input id="tfm_points_rating" name="tfm_points_rating" type="checkbox" class="checkbox" checked="checked" style="height:20px;width:20px;border-radius:2px;margin-right:12px">';
		}
		echo esc_html__( 'Points Rating', 'tfm-theme-boost' );
		echo '</label>';

		// ========================================================
		// Percent
		// ========================================================
		$value = get_post_meta( $post->ID, 'tfm_percent_rating', true );

		echo '<label for="tfm_percent_rating" style="padding:10px 0 10px 0; display:block">';
		if ($value == '') {
			echo ' <input id="tfm_percent_rating" name="tfm_percent_rating" type="checkbox" class="checkbox" style="height:20px;width:20px;border-radius:2px;margin-right:12px">';
		} else {
			echo ' <input id="tfm_percent_rating" name="tfm_percent_rating" type="checkbox" class="checkbox" checked="checked" style="height:20px;width:20px;border-radius:2px;margin-right:12px">';
		}
		echo esc_html__( 'Percent Rating', 'tfm-theme-boost' );
		echo '</label>';


}

}

// ========================================================
// Save data
// ========================================================

if ( ! function_exists( 'tfm_save_meta_post_data' ) ) {

	function tfm_save_meta_post_data( $post_id ) {

		// Return if meta-box doesnt exist
		if ( ! isset( $_POST['tfm_post_meta_nonce'] ) ) {
			return;
		}
		// Return if nonce is not valid
		if ( ! wp_verify_nonce( $_POST['tfm_post_meta_nonce'], basename( __FILE__ ))) {
			return;
		}
		// Return if doing and autosave
		if ( defined( 'DOING_AUTOAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		// Return if user does not have permisson
		if ( ! current_user_can( 'edit_post', $post_id )) {
			return;
		}

		// ========================================================
		// Single Post
		// ========================================================

		// Fullwidth media checkbox

		$full_width_checkbox = false;

		if (isset($_POST['tfm_single_full_width']))
	    {
	        $full_width_checkbox = true;
	    } 

		update_post_meta( $post_id, 'tfm_single_full_width', $full_width_checkbox );

		// Featured media checkbox

		$featured_media_checkbox = false;

		if (isset($_POST['tfm_disable_featured_media']))
	    {
	        $featured_media_checkbox = true;
	    } 

		update_post_meta( $post_id, 'tfm_disable_featured_media', $featured_media_checkbox );

		// Featured post chckbox

		$tfm_featured_post_checkbox = false;

		if (isset($_POST['tfm_featured_post']))
	    {
	        $tfm_featured_post_checkbox = true;
	    } 

		update_post_meta( $post_id, 'tfm_featured_post', $tfm_featured_post_checkbox );

		// Post style 

		$single_post_style = '';

		if (isset($_POST['tfm_single_post_style']))
	    {
	        $single_post_style = $_POST['tfm_single_post_style'];
	    } 

		update_post_meta( $post_id, 'tfm_single_post_style', $single_post_style );

		// Post thumbnail

		$single_post_thumbnail_size = '';

		if (isset($_POST['tfm_single_post_thumbnail_size']))
	    {
	        $single_post_thumbnail_size = $_POST['tfm_single_post_thumbnail_size'];
	    } 

		update_post_meta( $post_id, 'tfm_single_post_thumbnail_size', $single_post_thumbnail_size );

		// Post sidebar

		$single_post_sidebar = '';

		if (isset($_POST['tfm_single_post_sidebar']))
	    {
	        $single_post_sidebar = $_POST['tfm_single_post_sidebar'];
	    } 

		update_post_meta( $post_id, 'tfm_single_post_sidebar', $single_post_sidebar );

		// ========================================================
		// Page
		// ========================================================

		// Page sidebar

		$single_page_sidebar = '';

		if (isset($_POST['tfm_single_page_sidebar']))
	    {
	        $single_page_sidebar = $_POST['tfm_single_page_sidebar'];
	    } 

		update_post_meta( $post_id, 'tfm_single_page_sidebar', $single_page_sidebar );

		// ========================================================
		// Ratings
		// ========================================================


		// Ratings range

		$simple_ratings_range = '';

		if (isset($_POST['tfm_simple_ratings_range']))
	    {
	        $simple_ratings_range = $_POST['tfm_simple_ratings_range'];
	    } 

		update_post_meta( $post_id, 'tfm_simple_ratings_range', $simple_ratings_range );

		// Ratings value

		if ( isset( $_REQUEST['tfm_simple_ratings_score'] ) ) {
			update_post_meta( $post_id, 'tfm_simple_ratings_score', sanitize_text_field( $_POST['tfm_simple_ratings_score'] ) );
		}

		// Star rating

		$star_rating = false;

		if (isset($_POST['tfm_star_rating']))
	    {
	        $star_rating = true;
	    } 

		update_post_meta( $post_id, 'tfm_star_rating', $star_rating );

		// Scale rating

		$scale_rating = false;

		if (isset($_POST['tfm_scale_rating']))
	    {
	        $scale_rating = true;
	    } 

		update_post_meta( $post_id, 'tfm_scale_rating', $scale_rating );

		// Points rating

		$points_rating = false;

		if (isset($_POST['tfm_points_rating']))
	    {
	        $points_rating = true;
	    } 

		update_post_meta( $post_id, 'tfm_points_rating', $points_rating );

		// Percent rating

		$percent_rating = false;

		if (isset($_POST['tfm_percent_rating']))
	    {
	        $percent_rating = true;
	    } 

		update_post_meta( $post_id, 'tfm_percent_rating', $percent_rating );

	}
}

add_action( 'save_post', 'tfm_save_meta_post_data' );


?>