<?php

// ========================================================
// Custom CSS
// ========================================================

if ( ! function_exists( 'tfm_theme_boost_custom_css' ) ) {

function tfm_theme_boost_custom_css( ) {

	// MailChimp Footer custom CSS

	$custom_css['tfm_before_footer_background'] = ( '' !== get_theme_mod( 'tfm_before_footer_background', '' ) ? '.tfm-before-footer-section { background:' . get_theme_mod( 'tfm_before_footer_background', '' ) . ';}' : '' );
	$custom_css['tfm_before_footer_title_color'] = ( '' !== get_theme_mod( 'tfm_before_footer_title_color', '' ) ? '.tfm-before-footer-section .widgettitle, .tfm-before-footer-section .widget-title { color:' . get_theme_mod( 'tfm_before_footer_title_color', '' ) . ';}' : '' );
	$custom_css['tfm_before_footer_text_color'] = ( '' !== get_theme_mod( 'tfm_before_footer_text_color', '' ) ? '.tfm-before-footer-section .widget, .tfm-before-footer-section .widget label { color:' . get_theme_mod( 'tfm_before_footer_text_color', '' ) . ';}' : '' );
	$custom_css['tfm_before_footer_button_background'] = ( '' !== get_theme_mod( 'tfm_before_footer_button_background', '' ) ? '.tfm-before-footer-section button, .tfm-before-footer-section input[type="submit"] { background:' . get_theme_mod( 'tfm_before_footer_button_background', '' ) . ';}' : '' );
	$custom_css['tfm_before_footer_button_color'] = ( '' !== get_theme_mod( 'tfm_before_footer_button_color', '' ) ? '.tfm-before-footer-section button, .tfm-before-footer-section input[type="submit"] { color:' . get_theme_mod( 'tfm_before_footer_button_color', '' ) . ';}' : '' );

	// Featured post CSS

	$custom_css['tfm_featured_post_background'] = ( '' !== get_theme_mod( 'tfm_featured_post_background', '' ) ? 'body:not(.single) .tfm-featured-post.has-tfm-background:not(.cover) .entry-wrapper { background:' . get_theme_mod( 'tfm_featured_post_background', '' ) . ' !important;} body:not(.single) .tfm-featured-post.has-tfm-background:not(.cover) .formats-key > * { border-color:' . get_theme_mod( 'tfm_featured_post_background', '' ) . ';}' : '' );
	$custom_css['tfm_featured_post_color'] = ( '' !== get_theme_mod( 'tfm_featured_post_color', '' ) ? 'body:not(.single) .tfm-featured-post:not(.cover) a, body:not(.single) .tfm-featured-post:not(.cover) .entry-content, body:not(.single) .tfm-featured-post:not(.cover) .entry-meta, body:not(.single) .tfm-featured-post:not(.cover) .entry-meta a[class*="cat-link"], body:not(.single) .tfm-featured-post:not(.cover) .after-title-meta li:not(.entry-meta-avatar):not(:last-child)::after { color:' . get_theme_mod( 'tfm_featured_post_color', '' ) . ';}' : '' );

	// ========================================================
	// Featured Posts
	// ========================================================

	if ( apply_filters('tfm_theme_supports_featured_posts', false )) :

		$custom_css['tfm_featured_posts_background'] = ( '' !== get_theme_mod( 'tfm_featured_posts_background', '' ) ? '.tfm-featured-posts { background:' . get_theme_mod( 'tfm_featured_posts_background', '' ) . ';}' : '' );

		$custom_css['tfm_featured_posts_heading_color'] = ( '' !== get_theme_mod( 'tfm_featured_posts_heading_color', '' ) ? '.tfm-featured-posts h2 { color:' . get_theme_mod( 'tfm_featured_posts_heading_color', '' ) . ';}' : '' );

		$custom_css['tfm_featured_posts_link_color'] = ( '' !== get_theme_mod( 'tfm_featured_posts_link_color', '' ) ? '.tfm-featured-posts .entry-title-link, .tfm-featured-posts .entry-meta a, .tfm-featured-posts .entry-title a { color:' . get_theme_mod( 'tfm_featured_posts_link_color', '' ) . ';}' : '' );

		$custom_css['tfm_featured_posts_entry_meta_color'] = ( '' !== get_theme_mod( 'tfm_featured_posts_entry_meta_color', '' ) ? '.tfm-featured-posts .entry-meta li { color:' . get_theme_mod( 'tfm_featured_posts_entry_meta_color', '' ) . ';}' : '' );

		$custom_css['tfm_featured_posts_entry_meta_misc_color'] = ( '' !== get_theme_mod( 'tfm_featured_posts_entry_meta_misc_color', '' ) ? '.tfm-featured-posts.post-grid .article .after-title-meta li::after, .tfm-featured-posts.post-grid .article .after-title-meta li::before { color:' . get_theme_mod( 'tfm_featured_posts_entry_meta_misc_color', '' ) . ';}' : '' );

	endif;

	// After header sidebar

	$custom_css['tfm_ad_after_header_background'] = ( '' !== get_theme_mod( 'tfm_ad_after_header_background', '' ) ? '.tfm-after-header-sidebar { background:' . get_theme_mod( 'tfm_ad_after_header_background', '' ) . ';}' : '' );
	$custom_css['tfm_ad_after_header_border_color'] = ( '' !== get_theme_mod( 'tfm_ad_after_header_background', '' ) ? '.tfm-after-header-sidebar { border-color:' . get_theme_mod( 'tfm_ad_after_header_border_color', '' ) . ';}' : '' );

	// Breadcrumbs

	$custom_css['tfm_breadcrumbs_border_color'] = ( '' !== get_theme_mod( 'tfm_breadcrumbs_border_color', '' ) ? '.tfm-breadcrumbs.navxt, .tfm-breadcrumbs.yoast { border-color:' . get_theme_mod( 'tfm_breadcrumbs_border_color', '' ) . ';}' : '' );

	// Ratings

	$custom_css['tfm_star_rating_color'] = ( '' !== get_theme_mod( 'tfm_star_rating_color', '' ) ? '.tfm-rating-stars .star::before, .tfm-rating-stars .star:not(.none)::after { color:' . get_theme_mod( 'tfm_star_rating_color', '' ) . ';}' : '' );

	$custom_css['tfm_scale_rating_color'] = ( '' !== get_theme_mod( 'tfm_scale_rating_color', '' ) ? '.tfm-rating-scale .scale { background:' . get_theme_mod( 'tfm_scale_rating_color', '' ) . ';}' : '' );

	$scale_low_color = '' !== get_theme_mod( 'tfm_scale_rating_low_color', '') ? get_theme_mod( 'tfm_scale_rating_low_color', '') : '';
	$scale_high_color = '' !== get_theme_mod( 'tfm_scale_rating_high_color', '') ? get_theme_mod( 'tfm_scale_rating_high_color', '') : '';

	if ( $scale_high_color || $scale_low_color ) {
		$custom_css['tfm_scale_high_low'] = ( $scale_high_color || $scale_low_color ) ? '.tfm-rating-scale { background: linear-gradient(to right,' : '';
		$custom_css['tfm_scale_high_low'] .= $scale_low_color ? $scale_low_color . ',' : 'var(--tfm-rating-scale-low-color),';
		$custom_css['tfm_scale_high_low'] .= $scale_high_color ? $scale_high_color : 'var(--tfm-rating-scale-high-color)';
		$custom_css['tfm_scale_high_low'] .= ( $scale_high_color || $scale_low_color ) ? ');}' : '';
	}

	$tfm_css = array_filter($custom_css);

	if ( count($tfm_css) !== 0 ) : ?>

<style type="text/css" id="tfm-theme-boost-custom-css">
<?php foreach ($tfm_css as $css ) {
	echo wp_strip_all_tags( $css ) . "\n";
} ?>
</style>
<?php endif;


	}

	add_action( 'wp_head', 'tfm_theme_boost_custom_css', 20 ); // Enqueue the CSS Inline Style after the main stylesheet

} ?>