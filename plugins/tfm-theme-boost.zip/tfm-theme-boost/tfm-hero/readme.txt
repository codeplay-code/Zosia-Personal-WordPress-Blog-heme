=== TFM Hero ===

Plugin Name: TFM Hero

Author: 3FortyMedia

Author URI: https://www.3forty.media/

Requires at least: 5.8

Tested up to: 6.0

Requires PHP: 7.0

License: GPLv2

License URI: https://www.gnu.org/licenses/gpl-2.0.html

=== Description ===
Displays Hero content (posts) in a choice of styles and layouts.

=== Changelog ===

= 1.1.5 =
* Fixed translation string

= 1.1.4 =
* Updated TFM ratings support

= 1.1.3 =
* Added TFM ratings support

= 1.1.2 =
* Minor JS file update

= 1.1.1 =
* Added variable thumbnail size

= 1.1 =
* Fixed translation string
* New Grid Offset Layouts

= 1.0 - Initial release =



