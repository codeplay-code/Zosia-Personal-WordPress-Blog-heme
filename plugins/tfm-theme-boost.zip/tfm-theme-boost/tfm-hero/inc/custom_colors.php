<?php 

/**
 * Customizer Colour Options
 *
 * @package WordPress
 * @subpackage 3FortyMedia
 * @since 1.0
 * @version 1.0
 */

/**
 * Custom CSS Colors for home block widgets
 */

function tfm_hero_custom_colors() {

            $custom_colors['arrow_border'] = ( '' !== get_theme_mod('tfm_hero_arrow_background', '' ) ? '.tfm-hero .slick-arrow { border-color: ' . get_theme_mod( 'tfm_hero_arrow_background', '' ) . ';}' : '' );
            $custom_colors['arrow_background'] = ( '' !== get_theme_mod('tfm_hero_arrow_background', '' ) ? '.tfm-hero .slick-arrow { background: ' . get_theme_mod( 'tfm_hero_arrow_background', '' ) . ';}' : '' );
             $custom_colors['arrow_color'] = ( '' !== get_theme_mod('tfm_hero_arrow_color', '' ) ? '.tfm-hero .slick-arrow { color: ' . get_theme_mod( 'tfm_hero_arrow_color', '' ) . ';}' : '' );
             $custom_colors['read_more_arrow'] = ( '' !== get_theme_mod( 'tfm_hero_button_color', '' ) ? '.tfm-hero .read-more::after { color: ' . get_theme_mod( 'tfm_hero_button_color', '' ) . ';}' : '' );
             $custom_colors['entry_meta_icon'] = ( '' !== get_theme_mod( 'tfm_hero_entry_meta_icon_color', '' ) ? '.tfm-hero .entry-read-more .entry-meta-read-time::after, .tfm-hero .entry-meta-comment-count::before { color: ' . get_theme_mod( 'tfm_hero_entry_meta_icon_color', '' ) . ' !important;}' : '' );
             $custom_colors['entry_meta_read_time'] = ( '' !== get_theme_mod( 'tfm_hero_entry_meta_color', '' ) ? '.tfm-hero .entry-read-more .entry-meta-read-time { color: ' . get_theme_mod( 'tfm_hero_entry_meta_color', '' ) . ';}' : '' );
             $custom_colors['tfm_stars_color'] = ( '' !== get_theme_mod( 'tfm_hero_tfm_stars_color', '' ) ? '.tfm-hero .tfm-rating-stars .star::before, .tfm-hero .tfm-rating-stars .star:not(.none)::after { color: ' . get_theme_mod( 'tfm_hero_tfm_stars_color', '' ) . ';}' : '' );

	$block_css = array_filter($custom_colors);

if ( count($block_css) !== 0 ) : ?>
<style type="text/css" id="tfm-hero-custom-css">
<?php foreach ($block_css as $css ) {
	echo wp_strip_all_tags( $css ) . "\n";
} ?>
</style>

<?php endif;

} // End function

add_action( 'wp_head', 'tfm_hero_custom_colors' ); // Enqueue the CSS Inline Style after the main stylesheet

 ?>