<?php

/**
 * TFM Hero Hooks
 *
 *
 * @package WordPress
 * @subpackage Mura
 * @since 1.0
 * @version 1.0
 */

// ========================================================
// Custom Hooks
// ========================================================
function tfm_hero_prepend_after_title_meta() {
    do_action('tfm_hero_prepend_after_title_meta');
}
function tfm_hero_append_after_title_meta() {
    do_action('tfm_hero_append_after_title_meta');
}
function tfm_hero_after_continue_reading_button() {
    do_action('tfm_hero_after_continue_reading_button');
}
function tfm_hero_after_after_title_meta() {
    do_action('tfm_hero_after_after_title_meta');
}
function tfm_hero_entry_header_open() {
    do_action( 'tfm_hero_entry_header_open');
}
function tfm_hero_entry_header_close() {
    do_action( 'tfm_hero_entry_header_close');
}
function tfm_hero_after_entry_title() {
    do_action( 'tfm_hero_after_entry_title');
}

?>