<?php

/**
Plugin Name: TFM: Hero
Plugin URI:  http://www.3forty.media
Description: Displays Hero content (posts) in a choice of styles and layouts
Version:     1.1.6
Author:      3FortyMedia
Author URI:  http://www.3forty.media
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// ========================================================
// Check we are enabled in plugin settings
// ========================================================
$tfm_theme_boost_options = get_option( 'tfm_theme_boost_option_name' );

if ( ! isset($tfm_theme_boost_options['tfm_hero'])) {
	return;
}

// ========================================================
// Lets go...
// ========================================================
if ( ! function_exists('tfm_hero') ) {

	define( 'TFM_HERO__PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

	// ========================================================
	// Hero after header hook
	// ========================================================

	function tfm_hero( ) {

			if ( locate_template( 'template-parts/plugin-parts/tfm-hero/content.php', false ) ) {
				locate_template( 'template-parts/plugin-parts/tfm-hero/content.php', true);
			} else {
				include( TFM_HERO__PLUGIN_DIR . 'plugin-parts/content.php' );
			}

	}

	// After header hook
	add_action('tfm_after_header', 'tfm_hero', 20 );

	// ========================================================
	// Enqueue assets
	// ========================================================

	function tfm_hero_scripts() {

		$slider_active = true; // Slider active by default
		$hero_active = ( ( is_front_page() && get_theme_mod( 'tfm_hero', true ) ) || ( is_home() && 'page' === get_option( 'show_on_front') && get_theme_mod( 'tfm_hero_blog', true ) ) && ! is_paged() ? true : false );

		if ( apply_filters( 'ruki_hero_theme_supports_grid', false ) && get_theme_mod( 'tfm_hero_layout', 'grid' ) !== 'slider' ) {
			$slider_active = false;
		}


		// Enqueue slick assets
		if ( $hero_active && get_theme_mod( 'tfm_hero_post_num', 1 ) > 1  && $slider_active ) {
			wp_enqueue_style('slick', plugin_dir_url( __FILE__ ) . 'slick/slick.css', array(), '1.0.0', 'all');
			wp_enqueue_script( 'slick', plugin_dir_url( __FILE__ ) . 'slick/slick.min.js', array( 'jquery' ), '1.0.0', true);
			if ( ! wp_script_is( 'tfm-hero', 'enqueued' ) ) {		
				wp_enqueue_script( 'tfm-hero', plugin_dir_url( __FILE__ ) . 'js/hero.js', array( 'jquery' ), '1.0.0', true);
			}
		}

	}
	add_action( 'wp_enqueue_scripts', 'tfm_hero_scripts', 100 );

	// ========================================================
	// Add class to body tag
	// ========================================================

	function tfm_hero_class( $classes ) {

		$hero_active = ( ( ( is_front_page() && get_theme_mod( 'tfm_hero', true ) ) || ( is_home() && 'page' === get_option( 'show_on_front') && get_theme_mod( 'tfm_hero_blog', true ) ) ) && ! is_paged() ? true : false );

		if ( $hero_active ) {
			$classes[] = 'has-tfm-hero';
		}
		if ( '' !== get_theme_mod( 'tfm_hero_background', '' ) ) {
			$classes[] = 'tfm-hero-has-background';
		}
		return $classes;
	}
	add_filter( 'body_class', 'tfm_hero_class' );


	// ========================================================
	// Create an Array of categories
	// ========================================================

	if ( ! function_exists( 'tfm_get_blog_categories' ) ) {

		function tfm_get_blog_categories() {

			$categories = get_categories('type=post');

			$cats = array('' => '');

			foreach( $categories as $category ) {
			    $cats[$category->term_id] = $category->name;
			}

			return $cats;
		}

	}


	// ========================================================
	// WP Query
	// ========================================================

	function tfm_hero_query_args() {

		include( TFM_HERO__PLUGIN_DIR . 'inc/vars.php' );

		// The query

		if ( '' !== $post_in ) {

				$query_args = array(
				    'posts_per_page' => $post_num,
				    'post__in' => $post_in,
				    'ignore_sticky_posts' => 1,
				    'orderby' => 'post__in',
				    'order' => '' . $sort_order . '',
				);

			} else {

				$query_args = array(
				    'posts_per_page' => $post_num,
				    'offset' => $post_offset, // Offset
					'cat' => $post_cat, // If we are diplaying posts from a category
					'tag__in' => $tag_in,
				    'ignore_sticky_posts' => 1,
				    'orderby' => $order_by, // If we are displaying popular posts
				    'order' => '' . $sort_order . '',
				    'post__not_in' => $post_not_in,
					'post_status' => array(      
						'publish',          // A published post or page.
						),
				);

			}

			return $query_args;
	}

	// ========================================================
	// Output entry meta
	// ========================================================

	function tfm_hero_get_entry_meta( $meta_data = array(), $extra_class = '' ) {

		include( TFM_HERO__PLUGIN_DIR . 'inc/vars.php' );

		// Make sure we don't have an empty array
		if ( ! $meta_data ) {
			$meta_data = apply_filters( 'tfm_hero_entry_meta_data', array( 'author', 'author_avatar', 'date', 'comment_count', 'read_time' ) );
		}

		// prepend a space for extra class
		if ( '' !== $extra_class ) {
			$extra_class = ' ' . $extra_class;
		}

		$html = '';

		if ( in_array('author_avatar', $meta_data ) && get_theme_mod( 'tfm_hero_entry_meta_author_avatar', false ) ) :

			$html .= '<li class="entry-meta-avatar">';

			$html .= '<a href="' . get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ) . '">';

			$html .= get_avatar( get_the_author_meta('ID'), 40 );

			$html .= '</a>';

			$html .= '</li>';

		endif;

		if ( in_array('author', $meta_data ) && get_theme_mod( 'tfm_hero_entry_meta_author', false ) ) :

			$html .= '<li class="entry-meta-author">';

			$html .= '<span class="screen-reader-text">' . esc_html__( 'Posted by', 'tfm-theme-boost' ) . '</span>';
			if ( get_theme_mod( 'tfm_hero_entry_meta_by', true ) ):
				$html .= '<i dir="ltr">' . esc_html__( 'by', 'tfm-theme-boost' ) . '</i> ';
				endif;
			$html .= '<a href="' . get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ) . '"' . $custom_color['entry_meta_link'] . '>' . get_the_author() . '</a>';

			$html .= '</li>';

		endif;


		if ( in_array('date', $meta_data ) && get_theme_mod( 'tfm_hero_entry_meta_date', false ) ) :

			$tfm_date = function_exists('tfm_human_entry_date') ? tfm_human_entry_date() : get_the_time( get_option( 'date_format' ));

			$html .= '<li class="entry-meta-date">';

			$title = get_the_title('','', false);

			if ( ! is_single( ) && strlen($title) == 0 ) {

			$html .= '<a href="' . get_the_permalink() . '">';

			}

			$html .= '<time datetime="' . get_the_date( 'Y-m-d' ) . '">' . $tfm_date . '</time>';

			if ( ! is_single( ) && strlen($title) == 0 ) {

			$html .= '</a>';

			}

		   $html .= '</li>';

		endif;

		if ( in_array('comment_count', $meta_data ) && get_theme_mod( 'tfm_hero_entry_meta_comment_count', false ) ) :

			$html .= '<li class="entry-meta-comment-count">';

			if ( is_single( ) ) : 

				$html .= '<a href="#comments">';

			endif;

			$comment_string = (int)get_comments_number() === 1 ? esc_html__( 'Comment', 'tfm-theme-boost' ) : esc_html__( 'Comments', 'tfm-theme-boost' );

			$html .= get_comments_number() . ' <span>' . esc_attr( $comment_string ) . '</span>';

			if ( is_single( ) ) :

				$html .= '</a>';

			endif;

		$html .= '</li>';

		endif;

		if ( in_array('read_time', $meta_data ) && function_exists( 'tfm_read_time' ) && get_theme_mod( 'tfm_hero_entry_meta_read_time', true ) ) :

			$html .= tfm_read_time( $forced_request = true, $return = true );

		endif;

		echo wp_kses_post( $html );

	}

	// ========================================================
	// Customizer settings
	// ========================================================
	include( TFM_HERO__PLUGIN_DIR . 'inc/customizer.php' );
	include( TFM_HERO__PLUGIN_DIR . 'inc/hooks.php' );
	include( TFM_HERO__PLUGIN_DIR . 'inc/custom_colors.php' );

} // End if function_exists( 'tfm_hero')

?>