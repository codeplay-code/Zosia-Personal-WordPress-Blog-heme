<?php

/**
 * 3FortyMedia Related Posts Plugin
 *
 * @since 1.0
 * @version 1.2
 */

?>

<?php 

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$is_product = false;
if ( class_exists('WooCommerce') ) {
	$is_product = is_product() ? true : false;
}

if ( ! is_single() || $is_product ) {
	return; // Return of not single
}

include( TFM_RELATED_POSTS__PLUGIN_DIR . 'inc/vars.php' );

?>

<?php if ( is_single() && get_theme_mod( 'tfm_related_posts', true ) ) : ?>
	
<?php 

	$posts_query = new WP_Query( tfm_related_posts_query_args() );

    if( $posts_query->have_posts( ) ):

    $count = 0;

     ?>


    <?php if ( get_theme_mod( 'tfm_related_posts_background', '' )): ?>

    <div class="tfm-related-posts-wrapper alignfull"<?php echo wp_kses( $custom_color['background'], $allowed_html ) ?>>

    <?php endif; ?>

	<div class="content-area post-grid tfm-related-posts <?php echo esc_attr( $cols_class . $has_title . $layout ); ?>" data-poststyle="<?php echo esc_attr( $post_style ); ?>" data-slides="<?php echo esc_attr( $post_num ); ?>" data-posts="<?php echo esc_attr( $post_num ); ?>" data-thumbnail="<?php echo esc_attr( $thumbnail_aspect_ratio ); ?>">

		<?php if ( $has_title || $has_subtitle ): ?>

				<div class="section-header related-posts-header">
					<h2 class="page-title"<?php echo wp_kses( $custom_color['title'], $allowed_html ) ?>><?php echo esc_html( get_theme_mod( 'tfm_related_posts_title', '' ) ); ?></h2>
					<?php if ( $has_subtitle ) :?>
						<p class="sub-title"<?php echo wp_kses( $custom_color['subtitle'], $allowed_html ) ?>><?php echo esc_html( get_theme_mod( 'tfm_related_posts_subtitle', '' )); ?></p>
					<?php endif; ?>
				</div>


		<?php endif; ?>

 
    <?php 

    /* Start the Loop */

    while ( $posts_query->have_posts( ) ) : $posts_query->the_post(); ?>

    	<?php

    	$count++;

    	// Some in loop classes
    	$thumbnail_class = ( '' !== get_the_post_thumbnail() && $show_thumbnail ? ' has-post-media has-post-thumbnail' . $thumbnail_aspect_ratio . '' : '' );
    	 ?>

    	<article class="post article <?php echo esc_attr( $meta_vars . $thumbnail_class ); ?>">

    		<div class="post-inner"<?php echo wp_kses( $custom_color['post_background_border'], $allowed_html ) ?>>

    		<?php if ( '' !== get_the_post_thumbnail() && $show_thumbnail ) : ?>
    			<div class="thumbnail-wrapper">
				<figure class="post-thumbnail">

						<a href="<?php the_permalink(); ?>">
							<?php the_post_thumbnail( 'medium_large' ); ?>
						</a>

				</figure>
			</div>

			<?php endif; ?>

			<div class="entry-wrapper"<?php echo wp_kses( $custom_color['post_background'], $allowed_html ) ?>>
	    	<div class="entry-header">

	    		<?php tfm_related_posts_entry_header_open(); ?>

				<?php if ( get_theme_mod( 'tfm_related_posts_entry_meta_category', true ) ) : ?>

				<div class="entry-meta before-title"<?php echo wp_kses( $custom_color['entry_meta'], $allowed_html ) ?>>

						<?php if ( function_exists( 'tfm_get_category' ) ) {

							tfm_get_category( get_theme_mod( 'tfm_related_posts_entry_meta_category_slugs', 1 ), get_theme_mod( 'tfm_related_posts_entry_meta_in', true ), 'tfm_related_posts' ); 

						} else {

							get_the_category();

						} ?>

				</div><!-- .entry-meta -->

		<?php endif; ?>

		<?php if ( get_theme_mod( 'tfm_related_posts_entry_title', true ) ) : ?>

			<?php the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark"' . wp_kses( $custom_color['entry_title'], $allowed_html ) . '>', '</a></h3>' ); ?>

		<?php endif; ?>

		<?php tfm_related_posts_after_entry_title(); ?>

		<?php if ( $has_after_title_meta ) : ?>

			<div class="entry-meta after-title">

				<ul class="after-title-meta"<?php echo wp_kses( $custom_color['entry_meta'], $allowed_html ) ?>>

					<?php tfm_related_posts_prepend_after_title_meta(); ?>

					<?php tfm_related_posts_get_entry_meta(); ?>

					<?php tfm_related_posts_append_after_title_meta(); ?>

				</ul>

			</div>

		<?php endif; ?>

		<?php

			if ( function_exists( 'tfm_ratings' ) && ( get_theme_mod( 'tfm_related_posts_tfm_star_rating', false ) || get_theme_mod( 'tfm_related_posts_tfm_points_rating', false ) || get_theme_mod( 'tfm_related_posts_tfm_percent_rating', false ) || get_theme_mod( 'tfm_related_posts_tfm_scale_rating', false ) ) ) {

				tfm_ratings( get_theme_mod( 'tfm_related_posts_tfm_star_rating', false ), get_theme_mod( 'tfm_related_posts_tfm_points_rating', false ), get_theme_mod( 'tfm_related_posts_tfm_percent_rating', false ), get_theme_mod( 'tfm_related_posts_tfm_scale_rating', false ), true ); // $star_rating, $points_rating, $percent_rating, $scale-rating, $forced_request

			} ?>

		<?php tfm_related_posts_after_after_title_meta(); ?>

		<?php tfm_related_posts_entry_header_close(); ?>

			</div><!-- .entry-header -->

			<?php if ( get_theme_mod( 'tfm_related_posts_excerpt', false ) ): ?>

				<div class="entry-content excerpt"<?php echo wp_kses( $custom_color['entry_content'], $allowed_html ) ?>>

				<?php echo esc_html(get_the_excerpt( )); ?>

				</div>

			<?php endif; ?>

			<?php

			// Read more

			if ( get_theme_mod( 'tfm_related_posts_read_more', false ) )  : ?>

				<ul class="entry-read-more"<?php echo wp_kses( $custom_color['entry_meta_border_color'], $allowed_html ) ?>>

					<li class="read-more-button"<?php echo wp_kses( $custom_color['entry_meta_border_color'], $allowed_html ) ?>><a href="<?php echo esc_url( get_permalink() ); ?>" class="button read-more"<?php echo wp_kses( $custom_color['button'], $allowed_html ) ?>><span><?php echo esc_html__( 'Continue Reading', 'tfm-theme-boost'); ?></span></a></li>

					<?php

					if ( function_exists( 'tfm_read_time' ) && get_theme_mod( 'tfm_related_posts_entry_meta_read_time', true ) ) {

						tfm_read_time( true );

					} ?>

					<?php tfm_related_posts_after_continue_reading_button(); ?>

				</ul>

			<?php endif; ?>

		</div>

	</div>

	    </article>

    <?php 

	endwhile;

	?>

	</div>

	<?php if ( get_theme_mod( 'tfm_related_posts_background', '' )): ?>
		</div>
	<?php endif;

    endif;

    wp_reset_postdata(); // Always reset

 	?>


<?php endif; ?>