<?php

/**
Plugin Name: TFM: Related Posts
Plugin URI:  http://www.3forty.media
Description: Configurable related post displays
Version:     1.2.4
Author:      3FortyMedia
Author URI:  http://www.3forty.media
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// ========================================================
// Check we are enabled in plugin settings
// ========================================================
$tfm_theme_boost_options = get_option( 'tfm_theme_boost_option_name' );

if ( ! isset($tfm_theme_boost_options['tfm_related_posts'])) {
	return;
}


if ( ! function_exists('tfm_related_posts') ) {

	define( 'TFM_RELATED_POSTS__PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

	// ========================================================
	// Related Posts function
	// ========================================================

	/**
	 * Check for custom files within theme folder
	 * */
	function tfm_related_posts( ) {

			if ( locate_template( 'template-parts/plugin-parts/tfm-related-posts/related-posts.php', false ) ) {
				locate_template( 'template-parts/plugin-parts/tfm-related-posts/related-posts.php', true);
			} else {
				include( TFM_RELATED_POSTS__PLUGIN_DIR . 'plugin-parts/related-posts.php' );
			}

	}
	add_action( 'tfm_after_comments', 'tfm_related_posts' );

	// ========================================================
	// Add class to body tag
	// ========================================================

	function tfm_related_posts_class( $classes ) {

		if ( is_single() && get_theme_mod( 'tfm_related_posts', true ) ) {
			$classes[] = 'has-tfm-related-posts';
		}
		if ( is_single() && apply_filters( 'tfm_related_posts_background', false ) && '' !== get_theme_mod( 'tfm_related_posts_background', '' ) ) {
			$classes[] = 'has-tfm-related-posts-background';
		}
		return $classes;
	}
	add_filter( 'body_class', 'tfm_related_posts_class' );

	// ========================================================
	// Query Args
	// ========================================================

	function tfm_related_posts_query_args() {

		include( TFM_RELATED_POSTS__PLUGIN_DIR . 'inc/vars.php' );

		global $post;

		if ( $relate_method === 'category' ) {

			$category = get_the_category($post->ID);
			$cat_ids = array();
			foreach($category as $post_cat) {
				$cat_ids[] = $post_cat->cat_ID;
			}

			$query_args = array(
				'post__not_in' => array($post->ID),
			    'post_type'      => 'post',
			    'posts_per_page' => $post_num,
			    'cat' => $cat_ids,
			    'post_status' => array(      
					'publish',
					),
			    'orderby' => $order_by,
			    'order' => '' . $sort_order . '',
				);

		} elseif ( $relate_method === 'author' ) {

				$query_args = array(
				'post__not_in' => array($post->ID),
			    'post_type'      => 'post',
			    'posts_per_page' => $post_num,
			    'author' => get_the_author_meta( 'ID' ),
			    'orderby' => $order_by,
			    'order' => '' . $sort_order . '',
				);

		} else {

			// Tags relationship method

			$tags = wp_get_post_tags($post->ID);
			$tag_ids = array();
			foreach( $tags as $post_tag ) { 
				$tag_ids[] = $post_tag->term_id;
			}

			if ( empty($tags) ) {
				return false;
			}

			$query_args = array(
			'post__not_in' => array($post->ID),
		    'post_type'      => 'post',
		    'posts_per_page' => $post_num,
		    'tag__in' => $tag_ids,
		    'post_status' => array(      
				'publish',
				),
		    'orderby' => $order_by,
		    'order' => '' . $sort_order . '',
			);

		}

		return $query_args;
	}


	// ========================================================
	// Output entry meta
	// ========================================================

	function tfm_related_posts_get_entry_meta( $meta_data = array(), $extra_class = '' ) {

		// Make sure we don't have an empty array
		if ( ! $meta_data ) {
			$meta_data = apply_filters( 'tfm_related_posts_entry_meta_data', array( 'author_avatar', 'author', 'date', 'comment_count', 'read_time' ) );
		}

		// prepend a space for extra class
		if ( '' !== $extra_class ) {
			$extra_class = ' ' . $extra_class;
		}

		$html = '';

		if ( in_array('author_avatar', $meta_data ) && get_theme_mod( 'tfm_related_posts_entry_meta_author_avatar', false ) ) :

			$html .= '<li class="entry-meta-avatar">';

			$html .= '<a href="' . get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ) . '">';

			$html .= get_avatar( get_the_author_meta('ID'), 40 );

			$html .= '</a>';

			$html .= '</li>';

		endif;

		if ( in_array('author', $meta_data ) && get_theme_mod( 'tfm_related_posts_entry_meta_author', true ) ) :

			$html .= '<li class="entry-meta-author">';

			$html .= '<span class="screen-reader-text">' . esc_html__( 'Posted by', 'tfm-theme-boost' ) . '</span>';
			if ( get_theme_mod( 'tfm_related_posts_entry_meta_by', true ) ):
				$html .= '<i dir="ltr">' . esc_html__( 'by', 'tfm-theme-boost' ) . '</i> ';
				endif;
			$html .= '<a href="' . get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ) . '">' . get_the_author() . '</a>';

			$html .= '</li>';

		endif;


		if ( in_array('date', $meta_data ) && get_theme_mod( 'tfm_related_posts_entry_meta_date', true ) ) :

			$html .= '<li class="entry-meta-date">';

			$title = get_the_title('','', false);

			if ( ! is_single( ) && strlen($title) == 0 ) {

			$html .= '<a href="' . get_the_permalink() . '">';

			}

			$html .= '<time datetime="' . get_the_date( 'Y-m-d' ) . '">' . get_the_time( get_option( 'date_format' ) ) . '</time>';

			if ( ! is_single( ) && strlen($title) == 0 ) {

			$html .= '</a>';

			}

		   $html .= '</li>';

		endif;

		if ( in_array('comment_count', $meta_data ) && get_theme_mod( 'tfm_related_posts_entry_meta_comment_count', true ) ) :

			$html .= '<li class="entry-meta-comment-count">';

			$comment_string = (int)get_comments_number() === 1 ? esc_html__( 'Comment', 'tfm-theme-boost' ) : esc_html__( 'Comments', 'tfm-theme-boost' );

			$html .= get_comments_number() . ' <span>' . esc_attr( $comment_string ) . '</span>';

		$html .= '</li>';

		endif;

		if ( in_array('comment_count', $meta_data ) && get_theme_mod( 'tfm_related_posts_entry_meta_read_time', false ) ) :

			$html .= tfm_read_time( $forced_request = true, $return = true );

		endif;

		echo wp_kses_post( $html );

	}

	// ========================================================
	// Include files
	// ========================================================
	include( TFM_RELATED_POSTS__PLUGIN_DIR . 'inc/customizer.php' );
	include( TFM_RELATED_POSTS__PLUGIN_DIR . 'inc/custom_colors.php' );
	include( TFM_RELATED_POSTS__PLUGIN_DIR . 'inc/hooks.php' );

} // End if function_exists( 'tfm_related_posts')



?>