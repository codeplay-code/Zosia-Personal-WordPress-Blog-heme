<?php

/**
 * 3FortyMedia Related Posts Plugin Vars
 *
 * @since 1.0
 * @version 1.1
 */

?>

<?php


$post_num = get_theme_mod( 'tfm_related_posts_num', 3 );
$post_cols = get_theme_mod( 'tfm_related_posts_cols', apply_filters( 'tfm_related_posts_max_cols', 4 ) );
if ( in_array('has-sidebar', get_body_class()) && $post_cols > apply_filters( 'tfm_related_posts_max_post_cols_with_sidebar', 2 ) )  {
	$post_cols = apply_filters( 'tfm_related_posts_max_post_cols_with_sidebar', 2 );
}
if ( $post_cols > apply_filters( 'tfm_related_posts_max_cols', 4 ) ) {
    $post_cols = apply_filters( 'tfm_related_posts_max_cols', 4 );
 }
$sort_order = get_theme_mod( 'tfm_related_posts_sort_order', 'rand' );
$order_by = $sort_order === 'rand' ? 'rand' : '';
$cols_class = 'cols-' . $post_cols;
$thumbnail_aspect_ratio = ' thumbnail-' . get_theme_mod( 'tfm_related_posts_image_size', 'landscape' );
$layout = ' ' . get_theme_mod( 'tfm_related_posts_layout', 'grid' );
$post_style = get_theme_mod( 'tfm_related_posts_style', 'default' );
$relate_method = get_theme_mod( 'tfm_related_posts_method', 'tags' );
$has_title = ( get_theme_mod( 'tfm_related_posts_title' ) ? ' has-title' : '' );
$has_subtitle = ( get_theme_mod( 'tfm_related_posts_subtitle' ) ? ' has-subtitle' : '' );
$show_thumbnail = get_theme_mod( 'tfm_related_posts_thumbnail', true );


// ========================================================
// Post Meta Vars
// ========================================================
$meta_var['author'] = ( get_theme_mod( 'tfm_related_posts_entry_meta_author', true ) ? 'has-author' : '' );
$meta_var['avatar'] = ( get_theme_mod( 'tfm_related_posts_entry_meta_author_avatar', false ) ? 'has-avatar' : '' );
$meta_var['excerpt'] = ( get_theme_mod( 'tfm_related_posts_excerpt', false ) ? 'has-excerpt' : '' );
$meta_var['read_time'] = ( get_theme_mod( 'tfm_related_posts_entry_meta_read_time', false ) ? 'has-tfm-read-time' : '' );
$meta_var['date'] = ( get_theme_mod( 'tfm_related_posts_entry_meta_date', true ) ? 'has-date' : '' );
$meta_var['comment_count'] = ( get_theme_mod( 'tfm_related_posts_entry_meta_date', true ) ? 'has-comment-count' : '' );
$meta_var['category'] = ( get_theme_mod( 'tfm_related_posts_entry_meta_category', true ) ? 'has-category-meta' : '' );
$meta_var['style'] = $post_style;
$meta_var['read_more'] = ( get_theme_mod( 'tfm_related_posts_read_more', false ) ? 'has-read-more' : '' );

// Post background class

// Get theme settings
$current_theme_settings = function_exists('tfm_general_settings') ? tfm_general_settings() : '';

$default_post_background = $current_theme_settings && array_key_exists('default_archive_post_background', $current_theme_settings ) ? $current_theme_settings['default_archive_post_background'] : '';

$related_post_background = '' !== get_theme_mod( 'tfm_related_posts_post_background', '' ) ? get_theme_mod( 'tfm_related_posts_post_background', '' ) : $default_post_background;

$meta_var['post_background'] = ( '' !== $related_post_background ? ' has-background' : '' );

// Border Class
$site_background = '#' . get_background_color();
$pseudo_background = '' === get_theme_mod( 'tfm_related_posts_background', '' ) ? $site_background : get_theme_mod( 'tfm_related_posts_background', '' );
$meta_var['post_border'] = '' !== get_theme_mod( 'tfm_related_posts_border_color', '' ) && get_theme_mod( 'tfm_related_posts_border_color', '' ) === $pseudo_background ? 'no-border' : '';

$meta_vars = join( ' ', $meta_var );

// Check for after title meta
$has_after_title_meta = ( $meta_var['author'] || $meta_var['avatar'] || $meta_var['read_time'] || $meta_var['date'] || $meta_var['comment_count'] ? true : false );

// ========================================================
// Custom Colors
// ========================================================
$style = ' style="';
$custom_color['background'] = ( get_theme_mod( 'tfm_related_posts_background', '' ) ? $style . 'background:' . get_theme_mod( 'tfm_related_posts_background', '' ) . '"' : '' );
$custom_color['title'] = ( get_theme_mod( 'tfm_related_posts_title_color', '' ) ? $style . 'color:' . get_theme_mod( 'tfm_related_posts_title_color', '' ) . '"' : '' );
$custom_color['subtitle'] = ( get_theme_mod( 'tfm_related_posts_subtitle_color', '' ) ? $style . 'color:' . get_theme_mod( 'tfm_related_posts_subtitle_color', '' ) . '"' : '' );
$custom_color['post_background'] = ( get_theme_mod( 'tfm_related_posts_post_background', '' ) ? $style . 'background:' . get_theme_mod( 'tfm_related_posts_post_background', '' ) . '"' : '' );
$custom_color['entry_title'] = ( get_theme_mod( 'tfm_related_posts_entry_title_color', '' ) ? $style . 'color:' . get_theme_mod( 'tfm_related_posts_entry_title_color', '' ) . '"' : '' );
$custom_color['entry_meta'] = ( get_theme_mod( 'tfm_related_posts_entry_meta_color', '' ) ? $style . 'color:' . get_theme_mod( 'tfm_related_posts_entry_meta_color', '' ) . '"' : '' );
$custom_color['entry_meta_link'] = ( get_theme_mod( 'tfm_related_posts_entry_meta_link_color', '' ) ? $style . 'color:' . get_theme_mod( 'tfm_related_posts_entry_meta_link_color', '' ) . '"' : '' );
$custom_color['entry_content'] = ( get_theme_mod( 'tfm_related_posts_entry_content_color', '' ) ? $style . 'color:' . get_theme_mod( 'tfm_related_posts_entry_content_color', '' ) . '"' : '' );

// Post Inner Background/Border

$post_background = get_theme_mod( 'tfm_related_posts_post_background', '' );
$post_border_color = get_theme_mod( 'tfm_related_posts_border_color', '' );

$custom_color['post_background_border'] = ( $post_background || $post_border_color ) ? $style : '';
$custom_color['post_background_border'] .= ( $post_background ? 'background:' . $post_background . ';' : '' );
$custom_color['post_background_border'] .= ( $post_border_color ? 'border-color:' . $post_border_color . '' : '' );
$custom_color['post_background_border'] .= ( $post_background || $post_border_color ) ? '"' : '';

// Button

$button_background = get_theme_mod( 'tfm_related_posts_continue_reading_button_background', '' );
$button_color = get_theme_mod( 'tfm_related_posts_continue_reading_button_color', '' );

$custom_color['button'] = ( $button_background || $button_color ) ? $style : '';
$custom_color['button'] .= ( $button_background ? 'background:' . $button_background . ';' : '' );
$custom_color['button'] .= ( $button_color ? 'color:' . $button_color . '' : '' );
$custom_color['button'] .= ( $button_background || $button_color ) ? '"' : '';

// End

$custom_color['entry_meta_border_color'] = ( get_theme_mod( 'tfm_related_posts_entry_meta_border_color', '' ) ? $style . 'border-color:' . get_theme_mod( 'tfm_related_posts_entry_meta_border_color', '' ) . '"' : '' );

$allowed_html = array(
    'style' => array()
    );



?>