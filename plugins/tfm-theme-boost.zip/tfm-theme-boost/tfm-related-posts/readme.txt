=== TFM Related Posts ===

Plugin Name: TFM Related Posts

Author: 3FortyMedia

Author URI: https://www.3forty.media/

Requires at least: 5.8

Tested up to: 6.0

Requires PHP: 7.0

License: GPLv2

License URI: https://www.gnu.org/licenses/gpl-2.0.html

=== Description ===
Display posts related to current post by tag or category

=== Changelog ===

= 1.2.4 =
* Fixed comment string translation error

= 1.2.4 =
* Added filters

= 1.2.2 =
* Added TFM ratings support

= 1.2.1 =
* Added sort order option

= 1.2 =
* Fixed translation string
* Added author relationship method

= 1.1 =
* Fixed displaying of posts when empty tags

= 1.0 - Initial release =



