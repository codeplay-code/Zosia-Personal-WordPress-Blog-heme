<?php

/**
 * TFM Social Media Widget
 *
 *
 * @package WordPress
 * @subpackage 3FortyMedia
 * @since 1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Register our widget
function register_tfm_social_widget() {
	register_widget( 'Tfm_Social_Widget' );
}
add_action( 'widgets_init', 'register_tfm_social_widget' );

class Tfm_Social_Widget extends WP_Widget {

	// Setup our widget

	public function __construct() {

		$widget_ops = array(
			'classname' => 'tfm_social_widget',
			'description' => esc_html__('Displays Links and Icons to your social media channels', 'tfm-social-plugin'),
		);

	parent::__construct( 'tfm_social_widget', esc_html__('TFM: Social Media Widget', 'tfm-social-plugin'), $widget_ops );

	}

	// Backend Display

	public function form($instance) {

		/* Default variables */

		$title = (!empty($instance['title']) ? $instance['title'] : '');
		$subtitle = (!empty($instance['subtitle']) ? $instance['subtitle'] : '');
		$show_text = ( isset($instance['show_text']) ? (bool) $instance['show_text'] : false );
		$icon_style = ( ! empty($instance['icon_style']) ? $instance['icon_style'] : 'icon-background' );
		$color_scheme = ( !empty($instance['color_scheme']) ? $instance['color_scheme'] : 'theme' );
		$round_icons = ( isset($instance['round_icons']) ? (bool) $instance['round_icons'] : false );

		// Widget admin form

		// Title
		$output = '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('title') ) . '">' . esc_html__('Title:', 'tfm-social-plugin') . '</label>';
		$output .= '<input type="text" class="widefat" id="' . esc_attr($this->get_field_id('title')) . '" name="' . esc_attr($this->get_field_name('title')) . '" value="' . esc_attr($title) . '">';
		$output .= '</p>';

		// SubTitle
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('subtitle') ) . '">' . esc_html__('Subtitle:', 'tfm-social-plugin') . '</label>';
		$output .= '<input type="text" class="widefat" id="' . esc_attr($this->get_field_id('subtitle')) . '" name="' . esc_attr($this->get_field_name('subtitle')) . '" value="' . esc_attr($subtitle) . '">';
		$output .= '</p>';

		// Icon Style
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('icon_style') ) . '">' . esc_html__('Icon Style:', 'tfm-social-plugin') . '</label>';
		$output .= '<select class="widefat" id="' . esc_attr($this->get_field_id('icon_style')) . '" name="' . esc_attr($this->get_field_name('icon_style')) . '">';
		$output .= '<option ' . selected( $icon_style, 'icon-background', false ) . ' value="icon-background">' . esc_html__('With Background', 'tfm-social-plugin') . '</option>';
		$output .= '<option ' . selected( $icon_style, 'icon', false ) . ' value="icon">' . esc_html__('No Background', 'tfm-social-plugin') . '</option>';
		$output .= '<option ' . selected( $icon_style, 'icon-border', false ) . ' value="icon-border">' . esc_html__('With Border', 'tfm-social-plugin') . '</option>';
		$output .= '</select>';
		$output .= '</p>';

		// Colour scheme
		$output .= '<p>';
		$output .= '<label for="' . esc_attr($this->get_field_id('color_scheme') ) . '">' . esc_html__('Colour Scheme:', 'tfm-social-plugin') . '</label>';
		$output .= '<select class="widefat" id="' . esc_attr($this->get_field_id('color_scheme')) . '" name="' . esc_attr($this->get_field_name('color_scheme')) . '">';
		$output .= '<option ' . selected( $color_scheme, 'theme', false ) . ' value="theme">' . esc_html__('Theme Colour Scheme', 'tfm-social-plugin') . '</option>';
		$output .= '<option ' . selected( $color_scheme, 'brand', false ) . ' value="brand">' . esc_html__('Brand Color Scheme', 'tfm-social-plugin') . '</option>';
		$output .= '</select>';
		$output .= '</p>';

		// Show social media text
		$output .= '<p>';
		$output .= '<input type="checkbox" class="checkbox" ' . checked( $show_text, 1, false ) . ' id="' . esc_attr($this->get_field_id('show_text')) . '" name="' . esc_attr($this->get_field_name('show_text')) . '">';
		$output .= '<label for="' . esc_attr($this->get_field_id('show_text') ) . '">' . esc_html__('Show Social Media Name:', 'tfm-social-plugin') . '</label>';
		$output .= '</p>';

		// Round
		$output .= '<p>';
		$output .= '<input type="checkbox" class="checkbox" ' . checked( $round_icons, 1, false ) . ' id="' . esc_attr($this->get_field_id('round_icons')) . '" name="' . esc_attr($this->get_field_name('round_icons')) . '">';
		$output .= '<label for="' . esc_attr($this->get_field_id('round_icons') ) . '">' . esc_html__('Round Icons:', 'tfm-social-plugin') . '</label>';
		$output .= '</p>';

		// Let the user know that they can't change the social options here but they can edit them in the settings panel

		$output .= '<p>' . esc_html__('Set your social media URLs in Appearance > Customize > TFM: Social Media Settings', 'tfm-social-plugin') . '</a>';


		// Escape the output
		$allowed_html = array(
			'p' => array(),
			'label' => array(
				'for' => array(),
			),
			'input' => array(
				'type' => array(),
				'class' => array(),
				'id' => array(),
				'name' => array(),
				'value' => array(),
				'checked' => array(),
			),
			'textarea' => array(
				'class' => array(),
				'id' => array(),
				'name' => array(),
			),
			'button' => array(
				'class' => array(),
				'id' => array(),
				'name' => array(),
			),
			'select' => array(
				'class' => array(),
				'id' => array(),
				'name' => array(),
			),
			'option' => array(
				'value' => array(),
				'selected' => array(),
			),
		);

		echo wp_kses( $output, $allowed_html );

	}

	// Update Widget

	public function update($new_instance, $old_instance) {

		$instance = array();
		$instance['title'] = (!empty($new_instance['title']) ? strip_tags($new_instance['title']) : '');
		$instance['subtitle'] = (!empty($new_instance['subtitle']) ? strip_tags($new_instance['subtitle']) : '');
		$instance['show_text'] = (isset( $new_instance['show_text'] ) ? (bool) $new_instance['show_text'] : false);
		$instance['icon_style'] = (!empty($new_instance['icon_style']) ? strip_tags($new_instance['icon_style']) : '');
		$instance['color_scheme'] = (!empty($new_instance['color_scheme']) ? strip_tags($new_instance['color_scheme']) : '');
		$instance['round_icons'] = (isset( $new_instance['round_icons'] ) ? (bool) $new_instance['round_icons'] : false);

		return $instance;

	}

	// Front End Display

	public function widget($args, $instance) {

		$title = (!empty($instance['title']) ? $instance['title'] : '');
		$subtitle = (!empty($instance['subtitle']) ? $instance['subtitle'] : '');
		$show_text = ( isset($instance['show_text']) ? (bool) $instance['show_text'] : false );
		$round_icons = ( isset($instance['round_icons']) ? (bool) $instance['round_icons'] : false );
		$icon_style = ( !empty($instance['icon_style']) ? $instance['icon_style'] : 'icon-background' );
		$color_scheme = ( !empty($instance['color_scheme']) ? $instance['color_scheme'] : 'theme' );
		$has_title = ( $title ? ' has-title' : '' );
		$has_subtitle = ( $subtitle ? ' has-subtitle' : '' );
		$wrapper_class = 'widget-wrapper';

		// Escape the output
		$allowed_html = array(
			'section' => array(
				'class' => array(),
				'id'  => array(),
			),
			'h3' => array(
				'class' => array(),
			),
			'h2' => array(
				'class' => array(),
			),
			'p' => array(),
			'strong' => array(),
			'b' => array(),
			'a' => array(),
			'em' => array(),
		);


		echo wp_kses( $args['before_widget'], $allowed_html );

		// Title
		if (!empty( $instance[ 'title' ])) :
			echo wp_kses( $args['before_title'], $allowed_html ) . apply_filters('widget_title', $instance['title']) . wp_kses( $args['after_title'], $allowed_html );
		endif;

		if ( !empty( $instance[ 'subtitle' ]) ) :
			echo '<p class="widget-subtitle">' . wp_kses_post( $instance[ 'subtitle' ] ) . '</p>';
		endif;

		tfm_social_media_icons( $icon_style, $color_scheme, $show_text, $round_icons, $wrapper_class, $has_title, $has_subtitle );

		echo wp_kses( $args['after_widget'], $allowed_html );

	}


} // End Class