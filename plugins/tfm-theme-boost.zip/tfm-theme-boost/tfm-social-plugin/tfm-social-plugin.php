<?php

/**
Plugin Name: TFM: Social Plugin
Plugin URI:  http://www.3forty.media
Description: Display links and icons to your social media channels in widgets and theme files and share content to social media channels.
Version:     1.2.6
Author:      3FortyMedia
Author URI:  http://www.3forty.media
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// ========================================================
// Check we are enabled in plugin settings
// ========================================================
$tfm_theme_boost_options = get_option( 'tfm_theme_boost_option_name' );

if ( ! isset($tfm_theme_boost_options['tfm_social'])) {
	return;
}

	define( 'TFM_SOCIAL_WIDGET__PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

	// ========================================================
	// Enqueue stylesheet & icons
	// ========================================================

	if ( ! function_exists( 'tfm_social_plugin_scripts' ) ) {

		function tfm_social_plugin_scripts() {

			wp_enqueue_style('tfm-social-icons', plugin_dir_url( __FILE__ ) . 'css/fontello/css/fontello.css', array(), null );
			wp_enqueue_style('tfm-social-styles', plugin_dir_url( __FILE__ )  . 'css/style.css', array(), '1.0.0', 'all');
			wp_style_add_data( 'tfm-social-styles', 'rtl', 'replace' );
		}
	}
	add_action( 'wp_enqueue_scripts', 'tfm_social_plugin_scripts', 10 );

	// ========================================================
	// Share content (single)
	// ========================================================

	if ( ! function_exists('tfm_share_content')) {

		function tfm_share_content( $show_text = false, $round = false, $icon_style = '', $color_scheme = '', $forced_request = false ) {

			if ( ! is_single() && ! is_page() ) {
				return false;
			}

			$is_product = false;
			if ( class_exists('WooCommerce') ) {
				$is_product = is_product() ? true : false;
			}

			$share_sites = tfm_get_share_sites();
			$share_status = array();

			foreach ($share_sites as $share_site ) {

				$share_status[$share_site] = get_theme_mod( 'tfm_share_post_' . $share_site, true );

			}

			$active_share_sites = array_filter($share_status);

			if  ( ( ( is_single( ) && ! $is_product && get_theme_mod( 'tfm_share_posts', true ) === true ) || ( is_page() && ! is_front_page() && get_theme_mod( 'tfm_share_pages', false ) === true ) || ( $is_product &&  get_theme_mod( 'tfm_share_products', false ) === true ) || $forced_request ) && ! empty( $active_share_sites )  ) {

				include( TFM_SOCIAL_WIDGET__PLUGIN_DIR . 'plugin-parts/share.php' );

			}

		}

	}

	add_action( 'tfm_after_wrap', 'tfm_share_content', 200 ); // Side
	add_action( 'tfm_hentry_footer_after', 'tfm_share_content' ); // Single footer
	add_action( 'tfm_page_footer', 'tfm_share_content' ); // Page footer
	add_action( 'tfm_after_after_title_meta', 'tfm_share_content', 100 );

	// ========================================================
	// Share archive posts
	// ========================================================

	/**
 * This is on a per theme basis
 */
if ( ! function_exists('tfm_share_archive_content')) {
	
	function tfm_share_archive_content( $is_active = false, $show_text = false, $round = false, $icon_style = '', $color_scheme = '', $forced_request = false,  $return = false ) {

		if ( is_single() || is_page() ) {
			return false;
		}

		if ( false === apply_filters( 'tfm_social_plugin_theme_supports_share_blog_list_posts', false )) {
			return;
		}

		$is_product = false;
		if ( class_exists('WooCommerce') ) {
			$is_product = is_product() ? true : false;
		}

		$share_sites = tfm_get_share_sites();
		$share_status = array();

		foreach ($share_sites as $share_site ) {

			$share_status[$share_site] = get_theme_mod( 'tfm_share_archive_post_' . $share_site, false );

		}

		$active_share_sites = array_filter($share_status);

		if ( ! empty( $active_share_sites ) || $forced_request ) {

			if ( $is_active ) {

				return true; // Return the active status to the calling request

			} else {

				if ( $return ) {

					// Probably a request from a theme

					ob_start();

					include( TFM_SOCIAL_WIDGET__PLUGIN_DIR . 'plugin-parts/share.php' );

					return ob_get_clean();

					// This avoids add_action hook

				} else {

					include( TFM_SOCIAL_WIDGET__PLUGIN_DIR . 'plugin-parts/share.php' );

				}


			}

		} else {

			if ( $is_active ) {
				return false; // return false status to calling request
			}

		}

	}

}
add_action( 'tfm_after_after_title_meta', 'tfm_share_archive_content', 10 );

	// ========================================================
	// Add social media channel author contact methods
	// ========================================================

	if ( ! function_exists('tfm_social_contact_methods')) {

		function tfm_social_contact_methods( $method ) {

			$methods = apply_filters( 'tfm_social_contact_list', array(
				'tfm_author_meta_twitter' => esc_html__( 'Twitter Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_facebook' => esc_html__( 'Facebook Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_instagram' => esc_html__( 'Instagram Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_youtube' => esc_html__( 'YouTube Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_tumblr' => esc_html__( 'Tumblr Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_pinterest' => esc_html__( 'Pinterest Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_dribbble' => esc_html__( 'Dribbble Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_linkedin' => esc_html__( 'Linkedin Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_soundcloud' => esc_html__( 'Soundcloud Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_spotify' => esc_html__( 'Spotify Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_medium' => esc_html__( 'Medium Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_500px' => esc_html__( '500px Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_vimeo' => esc_html__( 'Vimeo Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_vkontakte' => esc_html__( 'VK Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_mixcloud' => esc_html__( 'Mixcloud Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_gab' => esc_html__( 'Gab Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_minds' => esc_html__( 'Minds Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_bitchute' => esc_html__( 'Bitchute Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_steemit' => esc_html__( 'Steemit Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_tiktok' => esc_html__( 'TikTok Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_odnoklassniki' => esc_html__( 'Odnoklassniki Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_discord' => esc_html__( 'Discord Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_steam' => esc_html__( 'Steam Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_twitch' => esc_html__( 'Twitch Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_telegram' => esc_html__( 'Telegram Full URL', 'tfm-theme-boost' ),
				'tfm_author_meta_gettr' => esc_html__( 'Gettr Full URL', 'tfm-theme-boost' ),
		     ));

			return $methods;
		}

	}
	add_filter('user_contactmethods', 'tfm_social_contact_methods');

	// ========================================================
	// Array of social media sites
	// ========================================================

	if ( ! function_exists( 'tfm_get_social_sites') ) {

	    function tfm_get_social_sites() {

	    	$social_sites = apply_filters( 'tfm_social_sites_list', array(
	         	 'tfm_social_site_twitter',
	         	 'tfm_social_site_facebook',
	             'tfm_social_site_pinterest',
	             'tfm_social_site_youtube',
	             'tfm_social_site_instagram',
	             'tfm_social_site_flickr',
	             'tfm_social_site_vimeo',
	             'tfm_social_site_vkontakte',
	             'tfm_social_site_tumblr',
	             'tfm_social_site_dribbble',
	             'tfm_social_site_rss',
	    		 'tfm_social_site_email',
	             'tfm_social_site_linkedin',
	             'tfm_social_site_500px',
	             'tfm_social_site_soundcloud',
	             'tfm_social_site_spotify',
	             'tfm_social_site_mixcloud',
	             'tfm_social_site_medium',
	             'tfm_social_site_github',
	             'tfm_social_site_behance',
	             'tfm_social_site_reddit',
	             'tfm_social_site_gab',
	             'tfm_social_site_minds',
	             'tfm_social_site_bitchute',
	             'tfm_social_site_steemit',
	             'tfm_social_site_tiktok',
	             'tfm_social_site_odnoklassniki',
	             'tfm_social_site_discord',
	             'tfm_social_site_steam',
	             'tfm_social_site_twitch',
	             'tfm_social_site_telegram',
	             'tfm_social_site_gettr',
	             
	         ));

	     return $social_sites;

	    }

	}

	// ========================================================
	// Array of share post social media sites
	// ========================================================

	if ( ! function_exists( 'tfm_get_share_sites') ) {

	    function tfm_get_share_sites() {

	        $share_sites = array(
	            'twitter',
	            'facebook',
	            'pinterest',
	            'linkedin',
	            'tumblr',
	            'reddit',
	            'pocket',
	            'whatsapp',
	            'vk',
	            'odnoklassniki',
	            'telegram',
	            'gettr',

	        );

	        return $share_sites;

	    }

	}

	// ========================================================
	// Display Author Social Meta
	// ========================================================

	if ( ! function_exists('tfm_author_social_meta')) {

		function tfm_author_social_meta( $return = false, $style = '', $color_scheme = '', $show_text = false ) {

			if ( ( is_single() && get_theme_mod( 'tfm_single_author_social', true ) ) || ( is_author() && get_theme_mod( 'tfm_archive_author_social', false ) ) ) {

				include( TFM_SOCIAL_WIDGET__PLUGIN_DIR . 'plugin-parts/author-social-meta.php' );

				if ( $return ) {

					return $html;

				} else {

					echo wp_kses_post( $html );

				}

			}

		}

	}
	add_action( 'tfm_author_bio_bottom', 'tfm_author_social_meta' );

	// ========================================================
	// Display owner social media channels
	// ========================================================
	/**
	 * This function echo's icons in widgets and theme settings
	 */

	if ( ! function_exists( 'tfm_social_media_icons' ) ) {

		function tfm_social_media_icons( $style = '', $color_scheme = '', $show_text = false, $round_icons = false, $wrapper_class = '', $has_widget_title = '', $has_widget_subtitle = '' ) {

			  $social_sites = tfm_get_social_sites( );
			  $active_sites = array();

		     foreach( $social_sites as $social_site ) {

		            $active_sites[$social_site] = get_theme_mod( $social_site, '' );
		     }

		     $active_social_sites = array_filter($active_sites);

		     if ( ! empty( $active_social_sites ) ) {

		         $has_text = ( true === $show_text ? ' has-text' : '' );
				 $has_round_icons = ( true === $round_icons ? ' has-round-icons' : '' );

		         $wrapper_class = $wrapper_class ? ' ' . $wrapper_class : '';

		        echo '<div class="tfm-social-icons-wrapper' . $wrapper_class . $has_widget_title . $has_widget_subtitle . '">';

		     	echo '<ul class="tfm-social-icons' . ' ' . esc_attr( $style . ' ' . $color_scheme . $has_text . $has_round_icons ) . '">';

		         foreach ( $active_social_sites as $active_site => $value ) {

		         	// Remove tfm_social_site_ from string
		         	$site_name = str_replace('tfm_social_site_', '', $active_site );

		         	$text = ( true === $show_text ? $site_name : '' );

		         	// TikTok
		         	if ( $text === 'tiktok' ) {
		         		$text = 'TikTok';
		         	}

		         	$class = ( $site_name === '500px' ? 'px500' : $site_name );

		         	$icon = $site_name;

		         	// Rename icons to match fontello css

		         	if ( $icon === 'google-plus' ) {
		         		$icon = 'gplus';
		         	}
		         	if ( $icon === 'github') {
		         		$icon = 'git';
		         	}
		         	if ( $icon === 'reddit' ) {
		         		$icon = 'reddit-alien';
		         	}
		         	if ( $icon === 'email' ) {
		         		$icon = 'mail-alt';
		         	}

		             echo '<li class="tfm-social-icon ' . strtolower( esc_attr( $class ) ) . '">';
		             if ( $site_name === 'email' ) {
		             	$email_address = str_replace('http://', '', get_theme_mod( 'tfm_social_site_email', '' ) );
		             		echo '<a href="mailto:' . sanitize_email( $email_address ) . '" class="' . strtolower( esc_attr( $class ) ) . '" rel="nofollow noopener" target="_blank">';
		             	} else {
		             		echo '<a href="' . esc_url( get_theme_mod( $active_site ) ) . '" class="tfm-social-url ' . strtolower( esc_attr( $class ) ) . '" target="_blank">';
		             	}
		             echo '<span><i class="icon-' . esc_attr( $icon ) . '"></i></span><span class="tfm-social-name">' . esc_html( $text ) . '</span>';
		             echo '</a></li>';
		             }

		             echo '</ul>';
		             echo '</div>';

		     }

		}

	}

	// ========================================================
	// Output Social Icons within the theme Header
	// ========================================================

	if ( ! function_exists( 'tfm_social_icons_theme_header' ) ) {

	function tfm_social_icons_theme_header( ) {

			if  ( get_theme_mod( 'tfm_header_social', false ) ) {

				/*
				 * Style
				 * Colour scheme
				 * Show text
				 * Round Icons
				 * Wraper class
				 * Has widget title
				 * Has widget subtitle
				 */

				 tfm_social_media_icons( get_theme_mod( 'tfm_header_social_icon_style', 'icon-background' ), get_theme_mod( 'tfm_header_social_icon_color_scheme', 'brand' ), false, get_theme_mod( 'tfm_header_social_icon_round', false ), 'header-social' );

			}

	}

	}
	add_action( 'tfm_header_left', 'tfm_social_icons_theme_header' );

	// ========================================================
	// Output Social Icons within the theme Footer
	// ========================================================

	if ( ! function_exists( 'tfm_social_icons_theme_footer' ) ) {

	function tfm_social_icons_theme_footer( ) {

			if  ( get_theme_mod( 'tfm_footer_social', false ) ) {

				/*
				 * Style
				 * Colour scheme
				 * Show text
				 * Round Icons
				 * Wraper class
				 * Has widget title
				 * Has widget subtitle
				 */

				 tfm_social_media_icons( get_theme_mod( 'tfm_footer_social_icon_style', 'icon-background' ), get_theme_mod( 'tfm_footer_social_icon_color_scheme', 'brand' ), false, get_theme_mod( 'tfm_footer_social_icon_round', false ), 'footer-social' );

			}

	}

	}
	add_action( 'tfm_append_footer_bottom', 'tfm_social_icons_theme_footer' );

	// ========================================================
	// Add classes to body tag
	// ========================================================

	if ( ! function_exists( 'tfm_social_body_classes' ) ) {

		function tfm_social_body_classes( $classes ) {

			if ( ( is_single() && get_theme_mod( 'tfm_single_author_social', true ) ) || ( is_author() && get_theme_mod( 'tfm_archive_author_social', false ) ) ) :

				$classes[] = 'has-tfm-author-social';

			endif;

			return $classes;

		}

		add_filter( 'body_class', 'tfm_social_body_classes', 20);

	}

	// ========================================================
	// Add classes to post_class() tag
	// ========================================================

	if ( ! function_exists( 'tfm_social_post_class' ) ) {

		function tfm_social_post_class( $classes ) {

			$share_sites = tfm_get_share_sites();
			$share_status = array();

			foreach ($share_sites as $share_site ) {

				$share_status[$share_site] = get_theme_mod( 'tfm_share_archive_post_' . $share_site, false );

			}

			$active_share_sites = array_filter($share_status);

			if ( ( is_home() || is_archive() || is_search() ) && ! empty( $active_share_sites )  ) :

				$classes[] = 'has-tfm-share-icons';

			endif;

			return $classes;

		}

		add_filter( 'post_class', 'tfm_social_post_class', 20 );

	}

	// ========================================================
	// Include files
	// ========================================================
	include( TFM_SOCIAL_WIDGET__PLUGIN_DIR . 'inc/customizer.php' );
	include( TFM_SOCIAL_WIDGET__PLUGIN_DIR . 'inc/widget.php' );

?>