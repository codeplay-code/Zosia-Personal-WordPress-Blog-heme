<?php
/**
 * ZOSIA CHILD THEME functions and definitions
 *
 *
 * @package WordPress
 * @subpackage zosia
 * @since 1.0
 * @version 1.0
 */

// ========================================================
// Add your own functions and customisations
// ========================================================
function mura_child_scripts() {
	wp_enqueue_style( 'mura-style', get_parent_theme_file_uri() . '/style.css', array(), null );
	wp_enqueue_style( 'mura-child-style', get_stylesheet_directory_uri() . '/style.css', array(), null );
}
add_action( 'wp_enqueue_scripts', 'mura_child_scripts' );
